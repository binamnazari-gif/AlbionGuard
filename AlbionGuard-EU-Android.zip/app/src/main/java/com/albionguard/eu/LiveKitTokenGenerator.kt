package com.albionguard.eu

import android.util.Base64
import org.json.JSONObject
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object LiveKitTokenGenerator {

    fun createJoinToken(
        apiKey: String,
        apiSecret: String,
        roomName: String,
        identity: String,
        displayName: String,
        ttlSeconds: Long = 24 * 3600L
    ): String {
        val nowSec = System.currentTimeMillis() / 1000L

        val headerJson = JSONObject().apply {
            put("alg", "HS256")
            put("typ", "JWT")
        }.toString()

        val videoGrant = JSONObject().apply {
            put("roomJoin", true)
            put("room", roomName)
            put("canPublish", true)
            put("canSubscribe", true)
            put("canPublishData", true)
        }

        val payloadJson = JSONObject().apply {
            put("iss", apiKey)
            put("sub", identity)
            put("name", displayName)
            put("iat", nowSec)
            put("nbf", nowSec - 10)
            put("exp", nowSec + ttlSeconds)
            put("video", videoGrant)
        }.toString()

        val encodedHeader = base64Url(headerJson.toByteArray(Charsets.UTF_8))
        val encodedPayload = base64Url(payloadJson.toByteArray(Charsets.UTF_8))
        val signingInput = "$encodedHeader.$encodedPayload"

        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(apiSecret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val signature = mac.doFinal(signingInput.toByteArray(Charsets.UTF_8))
        val encodedSig = base64Url(signature)

        return "$signingInput.$encodedSig"
    }

    private fun base64Url(bytes: ByteArray): String {
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}
