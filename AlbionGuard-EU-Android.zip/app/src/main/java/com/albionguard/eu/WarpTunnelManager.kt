package com.albionguard.eu

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.backend.Tunnel
import org.amnezia.awg.config.Config
import org.amnezia.awg.crypto.KeyPair
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class WarpCredentials(
    val privateKey: String,
    val peerPublicKey: String,
    val ipv4Address: String
)

data class WarpConnectResult(
    val success: Boolean,
    val endpoint: String,
    val rxBytes: Long,
    val message: String
)

object WarpTunnelManager {

    private const val PREFS_NAME = "albion_warp_prefs"
    private const val DEFAULT_CF_PEER_PUBKEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="

    // Curated Cloudflare WARP IPv4 endpoints & clean UDP ports for Iranian mobile carriers (with AmneziaWG Junk Packets)
    private val CANDIDATE_ENDPOINTS = listOf(
        "188.114.96.1:854",
        "188.114.97.1:859",
        "188.114.98.1:864",
        "188.114.99.1:878",
        "162.159.192.1:2408",
        "162.159.193.1:2408",
        "162.159.192.2:890",
        "162.159.193.2:903",
        "188.114.96.3:928",
        "188.114.97.3:942",
        "188.114.98.3:955",
        "188.114.99.3:987"
    )

    private var goBackend: GoBackend? = null
    private val albionTunnel = object : Tunnel {
        override fun getName(): String = "AlbionGuardAWG"
        override fun onStateChange(newState: Tunnel.State) {
            isWarpRunning = (newState == Tunnel.State.UP)
        }
    }

    @Volatile
    var isWarpRunning: Boolean = false
        private set

    @Volatile
    var activeEndpoint: String = ""
        private set

    private fun getBackend(context: Context): GoBackend {
        return goBackend ?: GoBackend(context.applicationContext).also { goBackend = it }
    }

    suspend fun connectAlbionOnlyWarp(
        context: Context,
        onProgress: suspend (stepText: String, percent: Int) -> Unit
    ): WarpConnectResult = withContext(Dispatchers.IO) {
        try {
            onProgress("در حال آماده‌سازی کلید ضد-DPI (AmneziaWG)...", 15)
            val creds = getOrRegisterWarpAccount(context)
                ?: return@withContext WarpConnectResult(
                    success = false,
                    endpoint = "",
                    rxBytes = 0L,
                    message = "ثبت کلید رایگان WARP ناموفق بود؛ فقط برای بار اول ۵ ثانیه با فیلترشکن یا وای‌فای بزنید تا کلید ذخیره شود."
                )

            val backend = getBackend(context)
            val albionInstalled = isPackageInstalled(context, NetworkProfiler.ALBION_PACKAGE)

            val maxToTry = CANDIDATE_ENDPOINTS.size
            for ((idx, endpoint) in CANDIDATE_ENDPOINTS.withIndex()) {
                val pct = 20 + ((idx + 1) * 75 / maxToTry)
                onProgress("تست AmneziaWG ضد-DPI روی $endpoint (${idx + 1}/$maxToTry)...", pct)

                try {
                    val confText = buildAmneziaWgConfig(creds, endpoint, albionInstalled)
                    val parsed = Config.parse(ByteArrayInputStream(confText.toByteArray(Charsets.UTF_8)))

                    try {
                        backend.setState(albionTunnel, Tunnel.State.DOWN, null)
                    } catch (_: Exception) {
                    }

                    backend.setState(albionTunnel, Tunnel.State.UP, parsed)

                    var rx = 0L
                    for (waitStep in 1..6) {
                        delay(450L)
                        val stats = backend.getStatistics(albionTunnel)
                        rx = stats.totalRx()
                        if (rx > 0L) break
                    }

                    if (rx > 0L) {
                        activeEndpoint = endpoint
                        isWarpRunning = true
                        return@withContext WarpConnectResult(
                            success = true,
                            endpoint = endpoint,
                            rxBytes = rx,
                            message = "تونل ضد-DPI (AmneziaWG) روی $endpoint فقط برای آلبیون متصل شد 🟢"
                        )
                    }
                } catch (_: Exception) {
                }
            }

            disconnect(context)
            WarpConnectResult(
                success = false,
                endpoint = "",
                rxBytes = 0L,
                message = "اندپوینت‌های AmneziaWG روی این سیم‌کارت پاسخ ندادند؛ لطفاً یک‌بار دیگر یا روی حالت DNS سریع تست کنید."
            )
        } catch (e: Exception) {
            disconnect(context)
            WarpConnectResult(
                success = false,
                endpoint = "",
                rxBytes = 0L,
                message = "خطا در راه‌اندازی تونل AmneziaWG: ${e.localizedMessage ?: "نامشخص"}"
            )
        }
    }

    fun disconnect(context: Context) {
        try {
            goBackend?.setState(albionTunnel, Tunnel.State.DOWN, null)
        } catch (_: Exception) {
        } finally {
            isWarpRunning = false
            activeEndpoint = ""
        }
    }

    /**
     * Builds an AmneziaWG obfuscated Cloudflare WARP config:
     * Jc=5, Jmin=10, Jmax=40 sends 5 random junk UDP packets before every handshake
     * to bypass Iranian carrier DPI while remaining 100% compatible with Cloudflare WARP!
     */
    private fun buildAmneziaWgConfig(
        creds: WarpCredentials,
        endpoint: String,
        restrictToAlbionOnly: Boolean
    ): String {
        val sb = StringBuilder()
        sb.append("[Interface]
")
        sb.append("PrivateKey = ").append(creds.privateKey).append("
")
        sb.append("Address = ").append(creds.ipv4Address).append("
")
        sb.append("DNS = 1.1.1.1, 1.0.0.1
")
        sb.append("MTU = 1280
")
        sb.append("Jc = 5
")
        sb.append("Jmin = 10
")
        sb.append("Jmax = 40
")
        sb.append("S1 = 0
")
        sb.append("S2 = 0
")
        sb.append("H1 = 1
")
        sb.append("H2 = 2
")
        sb.append("H3 = 3
")
        sb.append("H4 = 4
")
        if (restrictToAlbionOnly) {
            sb.append("IncludedApplications = ").append(NetworkProfiler.ALBION_PACKAGE).append("
")
        }
        sb.append("
[Peer]
")
        sb.append("PublicKey = ").append(creds.peerPublicKey).append("
")
        sb.append("AllowedIPs = 0.0.0.0/0
")
        sb.append("Endpoint = ").append(endpoint).append("
")
        sb.append("PersistentKeepalive = 15
")
        return sb.toString()
    }

    private fun getOrRegisterWarpAccount(context: Context): WarpCredentials? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedPriv = prefs.getString("priv_key", "") ?: ""
        val savedPeer = prefs.getString("peer_pub", "") ?: ""
        val savedIp = prefs.getString("ipv4", "") ?: ""

        if (savedPriv.isNotBlank() && savedPeer.isNotBlank() && savedIp.isNotBlank()) {
            return WarpCredentials(savedPriv, savedPeer, savedIp)
        }

        val apiUrls = listOf(
            "https://api.cloudflareclient.com/v0a2405/reg",
            "https://api.cloudflareclient.com/v0a2158/reg"
        )

        for (apiUrl in apiUrls) {
            try {
                val kp = KeyPair()
                val privB64 = kp.privateKey.toBase64()
                val pubB64 = kp.publicKey.toBase64()

                val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val payload = JSONObject().apply {
                    put("key", pubB64)
                    put("install_id", "")
                    put("fcm_token", "")
                    put("tos", isoFormat.format(Date()))
                    put("model", "Android")
                    put("serial_number", "")
                    put("locale", "en_US")
                }.toString()

                val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 7000
                    readTimeout = 7000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("User-Agent", "okhttp/3.12.1")
                    setRequestProperty("CF-Client-Version", "a-6.11-2223")
                }

                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode !in 200..299) {
                    conn.disconnect()
                    continue
                }

                val respStr = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()

                val json = JSONObject(respStr)
                val cfg = json.optJSONObject("config")
                val iface = cfg?.optJSONObject("interface")
                val addrs = iface?.optJSONObject("addresses")
                val v4Raw = addrs?.optString("v4", "172.16.0.2") ?: "172.16.0.2"
                val v4 = if (v4Raw.contains("/")) v4Raw else "$v4Raw/32"

                val peers = cfg?.optJSONArray("peers")
                val peerPub = peers?.optJSONObject(0)?.optString("public_key", DEFAULT_CF_PEER_PUBKEY)
                    ?.ifBlank { DEFAULT_CF_PEER_PUBKEY }
                    ?: DEFAULT_CF_PEER_PUBKEY

                prefs.edit()
                    .putString("priv_key", privB64)
                    .putString("peer_pub", peerPub)
                    .putString("ipv4", v4)
                    .apply()

                return WarpCredentials(privB64, peerPub, v4)
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun isPackageInstalled(context: Context, pkgName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(pkgName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkgName, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
