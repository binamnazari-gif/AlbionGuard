package com.albionguard.eu

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.backend.Tunnel
import org.amnezia.awg.config.Config
import org.amnezia.awg.crypto.KeyPair
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class WarpCredentials(
    val privateKey: String,
    val peerPublicKey: String,
    val ipv4Address: String
)

data class WarpConnectResult(
    val success: Boolean,
    val endpoint: String,
    val rxBytes: Long,
    val message: String
)

object WarpTunnelManager {

    private const val PREFS_NAME = "albion_warp_prefs"
    private const val DEFAULT_CF_PEER_PUBKEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="

    private val CANDIDATE_ENDPOINTS = listOf(
        "188.114.96.1:854",
        "188.114.97.1:859",
        "188.114.98.1:864",
        "188.114.99.1:878",
        "162.159.192.1:2408",
        "162.159.193.1:2408",
        "162.159.192.2:890",
        "162.159.193.2:903",
        "188.114.96.3:928",
        "188.114.97.3:942",
        "188.114.98.3:955",
        "188.114.99.3:987"
    )

    private var goBackend: GoBackend? = null
    private val albionTunnel = object : Tunnel {
        override fun getName(): String = "AlbionGuardAWG"
        override fun onStateChange(newState: Tunnel.State) {
            isWarpRunning = (newState == Tunnel.State.UP)
        }
        override fun isIpv4ResolutionPreferred(): Boolean = true
    }

    @Volatile
    var isWarpRunning: Boolean = false
        private set

    @Volatile
    var activeEndpoint: String = ""
        private set

    private fun getBackend(context: Context): GoBackend {
        return goBackend ?: createGoBackend(context.applicationContext).also { goBackend = it }
    }

    private fun createGoBackend(appContext: Context): GoBackend {
        val ctors = GoBackend::class.java.constructors
        ctors.firstOrNull { it.parameterTypes.size == 1 }?.let {
            return it.newInstance(appContext) as GoBackend
        }
        val twoArg = ctors.first { it.parameterTypes.size == 2 }
        val secondType = twoArg.parameterTypes[1]
        val secondArg: Any? = if (secondType.isInterface) {
            java.lang.reflect.Proxy.newProxyInstance(
                secondType.classLoader,
                arrayOf(secondType)
            ) { _, method, _ ->
                when (method.returnType) {
                    Boolean::class.javaPrimitiveType -> false
                    Int::class.javaPrimitiveType -> 0
                    Long::class.javaPrimitiveType -> 0L
                    else -> null
                }
            }
        } else {
            null
        }
        return twoArg.newInstance(appContext, secondArg) as GoBackend
    }

    suspend fun connectAlbionOnlyWarp(
        context: Context,
        onProgress: suspend (stepText: String, percent: Int) -> Unit
    ): WarpConnectResult = withContext(Dispatchers.IO) {
        try {
            onProgress("در حال آماده‌سازی کلید ضد-DPI (AmneziaWG)...", 10)
            val creds = getOrRegisterWarpAccount(context)
                ?: return@withContext WarpConnectResult(
                    success = false,
                    endpoint = "",
                    rxBytes = 0L,
                    message = "ثبت کلید رایگان WARP ناموفق بود؛ فقط برای بار اول ۵ ثانیه با فیلترشکن یا وای‌فای بزنید تا کلید ذخیره شود."
                )

            val backend = getBackend(context)
            val albionInstalled = isPackageInstalled(context, NetworkProfiler.ALBION_PACKAGE)
            val maxToTry = CANDIDATE_ENDPOINTS.size

            for ((idx, endpoint) in CANDIDATE_ENDPOINTS.withIndex()) {
                val pct = 15 + ((idx + 1) * 80 / maxToTry)
                onProgress("تست واقعی آلبیون روی $endpoint (${idx + 1}/$maxToTry)...", pct)

                try {
                    val confText = buildAmneziaWgConfig(
                        creds = creds,
                        endpoint = endpoint,
                        appPkg = context.packageName,
                        includeAlbion = albionInstalled
                    )
                    val parsed = Config.parse(ByteArrayInputStream(confText.toByteArray(Charsets.UTF_8)))

                    try {
                        backend.setState(albionTunnel, Tunnel.State.DOWN, null)
                    } catch (_: Exception) {
                    }

                    backend.setState(albionTunnel, Tunnel.State.UP, parsed)

                    // Wait for interface to come up, then verify REAL DNS + TCP reachability to live.albiononline.com
                    delay(800L)
                    val realTrafficOk = verifyAlbionThroughTunnel()
                    val rx = try {
                        backend.getStatistics(albionTunnel).totalRx()
                    } catch (_: Exception) {
                        0L
                    }

                    if (realTrafficOk && rx > 200L) {
                        activeEndpoint = endpoint
                        isWarpRunning = true
                        return@withContext WarpConnectResult(
                            success = true,
                            endpoint = endpoint,
                            rxBytes = rx,
                            message = "تونل ضد-DPI روی $endpoint وصل شد و دسترسی واقعی به live.albiononline.com تأیید شد 🟢"
                        )
                    }
                } catch (_: Exception) {
                }
            }

            disconnect(context)
            WarpConnectResult(
                success = false,
                endpoint = "",
                rxBytes = 0L,
                message = "هندشیک اولیه برقرار شد ولی ترافیک واقعی آلبیون از WARP عبور نکرد؛ لطفاً حالت «DNS سریع» یا وای‌فای را تست کنید."
            )
        } catch (e: Exception) {
            disconnect(context)
            WarpConnectResult(
                success = false,
                endpoint = "",
                rxBytes = 0L,
                message = "خطا در راه‌اندازی تونل AmneziaWG: ${e.localizedMessage ?: "نامشخص"}"
            )
        }
    }

    /**
     * Proves that DNS resolution + TCP traffic to live.albiononline.com ACTUALLY works
     * through the active AmneziaWG tunnel (prevents false green on 92-byte handshake-only endpoints!).
     */
    private fun verifyAlbionThroughTunnel(): Boolean {
        return try {
            val addr = InetAddress.getByName("live.albiononline.com")
            val ip = addr.hostAddress ?: return false
            if (ip.startsWith("10.10.34.") || ip == "0.0.0.0" || ip == "127.0.0.1") {
                return false
            }
            Socket().use { s ->
                s.connect(InetSocketAddress(addr, 443), 2500)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun disconnect(context: Context) {
        try {
            goBackend?.setState(albionTunnel, Tunnel.State.DOWN, null)
        } catch (_: Exception) {
        } finally {
            isWarpRunning = false
            activeEndpoint = ""
        }
    }

    private fun buildAmneziaWgConfig(
        creds: WarpCredentials,
        endpoint: String,
        appPkg: String,
        includeAlbion: Boolean
    ): String {
        val includedApps = mutableListOf(appPkg)
        if (includeAlbion) {
            includedApps.add(NetworkProfiler.ALBION_PACKAGE)
        }
        val lines = mutableListOf(
            "[Interface]",
            "PrivateKey = ${creds.privateKey}",
            "Address = ${creds.ipv4Address}",
            "DNS = 8.8.8.8, 1.1.1.1",
            "MTU = 1280",
            "Jc = 4",
            "Jmin = 40",
            "Jmax = 70",
            "S1 = 0",
            "S2 = 0",
            "H1 = 1",
            "H2 = 2",
            "H3 = 3",
            "H4 = 4",
            "IncludedApplications = ${includedApps.joinToString(", ")}",
            "",
            "[Peer]",
            "PublicKey = ${creds.peerPublicKey}",
            "AllowedIPs = 0.0.0.0/0",
            "Endpoint = $endpoint",
            "PersistentKeepalive = 15"
        )
        return lines.joinToString("\n")
    }

    private fun getOrRegisterWarpAccount(context: Context): WarpCredentials? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedPriv = prefs.getString("priv_key", "") ?: ""
        val savedPeer = prefs.getString("peer_pub", "") ?: ""
        val savedIp = prefs.getString("ipv4", "") ?: ""

        if (savedPriv.isNotBlank() && savedPeer.isNotBlank() && savedIp.isNotBlank()) {
            return WarpCredentials(savedPriv, savedPeer, savedIp)
        }

        val apiUrls = listOf(
            "https://api.cloudflareclient.com/v0a2405/reg",
            "https://api.cloudflareclient.com/v0a2158/reg"
        )

        for (apiUrl in apiUrls) {
            try {
                val kp = KeyPair()
                val privB64 = kp.privateKey.toBase64()
                val pubB64 = kp.publicKey.toBase64()

                val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val payload = JSONObject().apply {
                    put("key", pubB64)
                    put("install_id", "")
                    put("fcm_token", "")
                    put("tos", isoFormat.format(Date()))
                    put("model", "Android")
                    put("serial_number", "")
                    put("locale", "en_US")
                }.toString()

                val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 7000
                    readTimeout = 7000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("User-Agent", "okhttp/3.12.1")
                    setRequestProperty("CF-Client-Version", "a-6.11-2223")
                }

                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode !in 200..299) {
                    conn.disconnect()
                    continue
                }

                val respStr = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()

                val json = JSONObject(respStr)
                val cfg = json.optJSONObject("config")
                val iface = cfg?.optJSONObject("interface")
                val addrs = iface?.optJSONObject("addresses")
                val v4Raw = addrs?.optString("v4", "172.16.0.2") ?: "172.16.0.2"
                val v4 = if (v4Raw.contains("/")) v4Raw else "$v4Raw/32"

                val peers = cfg?.optJSONArray("peers")
                val peerPub = peers?.optJSONObject(0)?.optString("public_key", DEFAULT_CF_PEER_PUBKEY)
                    ?.ifBlank { DEFAULT_CF_PEER_PUBKEY }
                    ?: DEFAULT_CF_PEER_PUBKEY

                prefs.edit()
                    .putString("priv_key", privB64)
                    .putString("peer_pub", peerPub)
                    .putString("ipv4", v4)
                    .apply()

                return WarpCredentials(privB64, peerPub, v4)
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun isPackageInstalled(context: Context, pkgName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(pkgName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkgName, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
