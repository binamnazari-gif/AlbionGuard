package com.albionguard.eu

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat

class GuildVoiceService : Service() {

    companion object {
        const val ACTION_JOIN = "com.albionguard.eu.VOICE_JOIN"
        const val ACTION_LEAVE = "com.albionguard.eu.VOICE_LEAVE"
        const val ACTION_TOGGLE_MUTE = "com.albionguard.eu.VOICE_TOGGLE_MUTE"
        const val EXTRA_ROOM_CODE = "extra_room_code"

        private const val CHANNEL_ID = "albion_guild_voice_channel"
        private const val NOTIF_ID = 7072

        @Volatile
        var isVoiceActive: Boolean = false
            private set

        @Volatile
        var currentRoom: String = ""
            private set

        @Volatile
        var isMuted: Boolean = false
            private set

        /**
         * Uses Freifunk Munich public Jitsi SFU (Germany, zero account, zero time limit).
         * Server-relayed SFU works reliably across Iranian mobile CGNAT (unlike P2P).
         * Hash params force instant auto-join in pure Audio-Only mode with zero video bandwidth.
         */
        fun buildVoiceRoomUrl(roomCode: String, label: String = "Player"): String {
            val cleanRoom = sanitizeRoomCode(roomCode)
            val safeName = label.replace(Regex("[^A-Za-z0-9 _-]"), "").ifBlank { "Player" }
            return "https://meet.ffmuc.net/AlbionGuard-$cleanRoom" +
                "#config.startAudioOnly=true" +
                "&config.startWithVideoMuted=true" +
                "&config.startWithAudioMuted=false" +
                "&config.prejoinPageEnabled=false" +
                "&config.prejoinConfig.enabled=false" +
                "&config.disableDeepLinking=true" +
                "&config.p2p.enabled=false" +
                "&config.audioQuality.stereo=false" +
                "&config.audioQuality.opusMaxAverageBitrate=24000" +
                "&interfaceConfig.MOBILE_APP_PROMO=false" +
                "&userInfo.displayName=%22$safeName%22"
        }

        fun sanitizeRoomCode(raw: String): String {
            val cleaned = raw.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
            return if (cleaned.length >= 3) cleaned else "albion-iran"
        }
    }

    private var voiceWebView: WebView? = null
    private lateinit var audioManager: AudioManager
    private var previousAudioMode: Int = AudioManager.MODE_NORMAL

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LEAVE -> {
                leaveVoice()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_MUTE -> {
                toggleMute()
                return START_STICKY
            }
            else -> {
                val room = sanitizeRoomCode(intent?.getStringExtra(EXTRA_ROOM_CODE) ?: "albion-iran")
                joinVoice(room)
                return START_STICKY
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun joinVoice(room: String) {
        createNotificationChannel()
        currentRoom = room
        isVoiceActive = true
        isMuted = false

        try {
            previousAudioMode = audioManager.mode
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.isMicrophoneMute = false
        } catch (_: Exception) {
        }

        startForeground(NOTIF_ID, buildNotification())
        destroyWebView()

        val wv = WebView(applicationContext).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            // Desktop-like Chrome UA prevents Jitsi mobile interstitial redirect screen
            settings.userAgentString =
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest?) {
                    request ?: return
                    val audioResources = request.resources.filter {
                        it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                    }.toTypedArray()
                    if (audioResources.isNotEmpty()) {
                        request.grant(audioResources)
                    } else {
                        request.deny()
                    }
                }
            }
        }
        voiceWebView = wv
        wv.onResume()
        wv.resumeTimers()

        val url = buildVoiceRoomUrl(room, Build.MODEL)
        wv.loadUrl(url)
    }

    private fun toggleMute() {
        if (!isVoiceActive) return
        isMuted = !isMuted
        try {
            audioManager.isMicrophoneMute = isMuted
        } catch (_: Exception) {
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun leaveVoice() {
        isVoiceActive = false
        isMuted = false
        try {
            audioManager.isMicrophoneMute = false
            audioManager.mode = previousAudioMode
        } catch (_: Exception) {
        }
        destroyWebView()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun destroyWebView() {
        try {
            voiceWebView?.apply {
                loadUrl("about:blank")
                stopLoading()
                destroy()
            }
            voiceWebView = null
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        leaveVoice()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "اتاق ویس گیلد (فوق‌سبک)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "کنترل سریع میکروفون و اتاق صوتی گیلد وسط بازی"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val muteIntent = PendingIntent.getService(
            this,
            11,
            Intent(this, GuildVoiceService::class.java).apply { action = ACTION_TOGGLE_MUTE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val leaveIntent = PendingIntent.getService(
            this,
            12,
            Intent(this, GuildVoiceService::class.java).apply { action = ACTION_LEAVE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val micState = if (isMuted) "میکروفون بسته 🔇" else "میکروفون باز 🎙️"
        val muteBtnLabel = if (isMuted) "وصل میکروفون" else "بی‌صدا (Mute)"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("ویس گیلد • اتاق: $currentRoom")
            .setContentText("$micState • سرور آلمان (فقط صدا 24kbps)")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_btn_speak_now, muteBtnLabel, muteIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "قطع ویس", leaveIntent)
            .build()
    }
}
