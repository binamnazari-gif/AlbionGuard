package com.albionguard.eu

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import libv2ray.Libv2ray
import java.net.HttpURLConnection
import java.net.URL

data class RankedProxyNode(
    val node: ParsedProxyNode,
    val delayMs: Int
)

data class GamingPoolAuditResult(
    val success: Boolean,
    val topNodes: List<RankedProxyNode>,
    val totalParsed: Int,
    val message: String
)

object GuildConfigStore {

    private const val PREFS_NAME = "albion_xray_configs"
    private const val KEY_MANUAL_CONFIGS = "manual_configs_raw"

    // Central GitHub repo config pool — owner updates configs.txt once and all friends get fresh Germany configs automatically!
    const val REMOTE_GUILD_CONFIGS_URL =
        "https://raw.githubusercontent.com/binamnazari-gif/AlbionGuard/main/configs.txt"

    fun saveManualConfigs(context: Context, rawText: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MANUAL_CONFIGS, rawText.trim())
            .apply()
    }

    fun getManualConfigs(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_MANUAL_CONFIGS, "") ?: ""
    }

    suspend fun auditAndSelectTopNodes(
        context: Context,
        onProgress: suspend (stepText: String, percent: Int) -> Unit
    ): GamingPoolAuditResult = withContext(Dispatchers.IO) {
        Libv2ray.initCoreEnv(context.filesDir.absolutePath, "")

        onProgress("در حال دریافت لیست کانفیگ‌های آلمان...", 10)
        val combinedRaw = StringBuilder()

        val manual = getManualConfigs(context)
        if (manual.isNotBlank()) {
            combinedRaw.append(manual).append("\n")
        }

        // Also try fetching central guild configs.txt from GitHub (non-blocking if offline/empty)
        val remote = fetchRemoteConfigs()
        if (remote.isNotBlank()) {
            combinedRaw.append(remote).append("\n")
        }

        val parsedNodes = ProxyConfigParser.parseBatch(combinedRaw.toString())
        if (parsedNodes.isEmpty()) {
            return@withContext GamingPoolAuditResult(
                success = false,
                topNodes = emptyList(),
                totalParsed = 0,
                message = "هنوز کانفیگی وارد نشده! روی دکمه «کانفیگ‌ها» بزنید و لینک‌های VLESS / SS / Trojan آلمان را پیست کنید (یا در فایل configs.txt گیت‌هاب بگذارید)."
            )
        }

        val total = parsedNodes.size
        onProgress("در حال تست واقعی $total کانفیگ (به ترتیب سرعت و پایداری)...", 20)

        val semaphore = Semaphore(4)
        var completed = 0
        val lock = Any()

        val ranked = coroutineScope {
            parsedNodes.map { node ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val delayMs = measureNodeRealDelay(node)
                        val doneNow = synchronized(lock) {
                            completed++
                            completed
                        }
                        val pct = 20 + (doneNow * 75 / total)
                        onProgress("تست کانفیگ $doneNow از $total (${node.protocol})...", pct)
                        if (delayMs in 1..4500) RankedProxyNode(node, delayMs) else null
                    }
                }
            }.awaitAll().filterNotNull().sortedBy { it.delayMs }
        }

        if (ranked.isEmpty()) {
            return@withContext GamingPoolAuditResult(
                success = false,
                topNodes = emptyList(),
                totalParsed = total,
                message = "هیچ‌کدام از $total کانفیگ روی این اپراتور پاسخ ندادند؛ لطفاً کانفیگ‌های سالم‌تر اضافه کنید."
            )
        }

        val top5 = ranked.take(5)
        GamingPoolAuditResult(
            success = true,
            topNodes = top5,
            totalParsed = total,
            message = "${top5.size} کانفیگ سالم انتخاب شد؛ بهترین: ${top5.first().node.label} (${top5.first().delayMs}ms) با سوئیچ خودکار روی بقیه 🟢"
        )
    }

    private fun measureNodeRealDelay(node: ParsedProxyNode): Int {
        return try {
            val testJson = ProxyConfigParser.buildSingleTestConfig(node)
            val ms = Libv2ray.measureOutboundDelay(testJson, "https://www.gstatic.com/generate_204")
            if (ms > 0L) ms.toInt() else -1
        } catch (_: Exception) {
            -1
        }
    }

    private fun fetchRemoteConfigs(): String {
        return try {
            val conn = (URL(REMOTE_GUILD_CONFIGS_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("User-Agent", "AlbionGuard-Android")
            }
            if (conn.responseCode == 200) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                text
            } else {
                conn.disconnect()
                ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Resolves each pasted config's host to IPv4 and checks real country via ip-api.com batch API
     * (with flag/tag fallback) to keep ONLY Germany (DE) configs and strip all other countries.
     */
    suspend fun filterGermanyOnly(rawText: String): Pair<List<ParsedProxyNode>, Int> = withContext(Dispatchers.IO) {
        val allNodes = ProxyConfigParser.parseBatch(rawText)
        if (allNodes.isEmpty()) return@withContext emptyList<ParsedProxyNode>() to 0

        // Resolve hosts to IPv4 in parallel
        val nodeIps = coroutineScope {
            allNodes.map { node ->
                async(Dispatchers.IO) {
                    val ip = try {
                        java.net.InetAddress.getByName(node.host).hostAddress ?: node.host
                    } catch (_: Exception) {
                        node.host
                    }
                    node to ip
                }
            }.awaitAll()
        }

        // Batch GeoIP lookup via ip-api.com (up to 100 IPs in one fast HTTP POST)
        val ipToCountry = mutableMapOf<String, String>()
        try {
            val uniqueIps = nodeIps.map { it.second }.distinct().take(100)
            val arr = org.json.JSONArray()
            uniqueIps.forEach { arr.put(it) }

            val conn = (URL("http://ip-api.com/batch?fields=query,countryCode").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 6000
                readTimeout = 6000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(arr.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val respArr = org.json.JSONArray(body)
                for (i in 0 until respArr.length()) {
                    val obj = respArr.optJSONObject(i) ?: continue
                    val q = obj.optString("query", "")
                    val cc = obj.optString("countryCode", "")
                    if (q.isNotBlank() && cc.isNotBlank()) {
                        ipToCountry[q] = cc.uppercase()
                    }
                }
            }
            conn.disconnect()
        } catch (_: Exception) {
        }

        val germanyOnly = nodeIps.filter { (node, ip) ->
            val cc = ipToCountry[ip]
            if (cc != null) {
                cc == "DE"
            } else {
                // Fallback if GeoIP API is unreachable: check label for Germany flag/keywords
                node.label.contains("🇩🇪") ||
                    node.label.contains("germany", ignoreCase = true) ||
                    node.label.contains("frankfurt", ignoreCase = true) ||
                    Regex("\\bDE\\b", RegexOption.IGNORE_CASE).containsMatchIn(node.label)
            }
        }.map { it.first }

        germanyOnly to allNodes.size
    }
}
