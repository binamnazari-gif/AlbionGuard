package com.albionguard.eu

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import libv2ray.Libv2ray
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

data class RankedProxyNode(
    val node: ParsedProxyNode,
    val delayMs: Int,
    val countryCode: String
)

data class ConfigGroup5(
    val groupIndex: Int, // 1-based: گروه ۱، گروه ۲...
    val countryCode: String,
    val nodes: List<RankedProxyNode>
) {
    val bestPingMs: Int get() = nodes.firstOrNull()?.delayMs ?: 0
    val size: Int get() = nodes.size
}

data class CountryBucket(
    val countryCode: String,
    val flag: String,
    val persianName: String,
    val groups: List<ConfigGroup5>
) {
    val totalActive: Int get() = groups.sumOf { it.size }
    val bestPingMs: Int get() = groups.firstOrNull()?.bestPingMs ?: 9999
}

data class OrganizedPoolSnapshot(
    val updatedAtMs: Long,
    val totalScanned: Int,
    val totalActive: Int,
    val countries: List<CountryBucket>,
    val statusMessage: String
)

object GuildConfigStore {

    private const val PREFS_NAME = "albion_xray_configs"
    private const val KEY_MANUAL_CONFIGS = "manual_configs_raw"
    private const val KEY_CACHED_POOL_JSON = "cached_country_pool_v1"
    private const val KEY_SELECTED_COUNTRY = "selected_country_code"
    private const val KEY_SELECTED_GROUP_IDX = "selected_group_idx"

    const val REMOTE_GUILD_CONFIGS_URL =
        "https://raw.githubusercontent.com/binamnazari-gif/AlbionGuard/main/configs.txt"

    fun saveManualConfigs(context: Context, rawText: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MANUAL_CONFIGS, rawText.trim())
            .apply()
    }

    fun getManualConfigs(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_MANUAL_CONFIGS, "") ?: ""
    }

    fun saveSelection(context: Context, countryCode: String, groupIndex: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SELECTED_COUNTRY, countryCode)
            .putInt(KEY_SELECTED_GROUP_IDX, groupIndex)
            .apply()
    }

    fun getSelectedCountry(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SELECTED_COUNTRY, "") ?: ""
    }

    fun getSelectedGroupIndex(context: Context): Int {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SELECTED_GROUP_IDX, 1)
    }

    fun clearCache(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_CACHED_POOL_JSON)
            .apply()
    }

    fun loadCachedPool(context: Context): OrganizedPoolSnapshot? {
        val rawJson = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CACHED_POOL_JSON, "") ?: ""
        if (rawJson.isBlank()) return null

        return try {
            val root = JSONObject(rawJson)
            val updatedAt = root.optLong("updatedAtMs", 0L)
            val totalScanned = root.optInt("totalScanned", 0)
            val countriesArr = root.optJSONArray("countries") ?: JSONArray()
            val buckets = mutableListOf<CountryBucket>()

            for (i in 0 until countriesArr.length()) {
                val cObj = countriesArr.optJSONObject(i) ?: continue
                val cc = cObj.optString("countryCode", "UN")
                val nodesArr = cObj.optJSONArray("nodes") ?: JSONArray()
                val rankedNodes = mutableListOf<RankedProxyNode>()
                for (j in 0 until nodesArr.length()) {
                    val nObj = nodesArr.optJSONObject(j) ?: continue
                    val rawUri = nObj.optString("rawUri", "")
                    val delayMs = nObj.optInt("delayMs", -1)
                    val parsed = ProxyConfigParser.parseSingle(rawUri, "cached_${i}_$j")
                    if (parsed != null && delayMs > 0) {
                        rankedNodes.add(RankedProxyNode(parsed, delayMs, cc))
                    }
                }
                if (rankedNodes.isNotEmpty()) {
                    val sorted = rankedNodes.sortedBy { it.delayMs }
                    val groups = sorted.chunked(5).mapIndexed { gIdx, chunk ->
                        ConfigGroup5(gIdx + 1, cc, chunk)
                    }
                    val (flag, name) = countryMeta(cc)
                    buckets.add(CountryBucket(cc, flag, name, groups))
                }
            }

            val totalActive = buckets.sumOf { it.totalActive }
            if (totalActive == 0) return null
            OrganizedPoolSnapshot(
                updatedAtMs = updatedAt,
                totalScanned = totalScanned,
                totalActive = totalActive,
                countries = buckets,
                statusMessage = "$totalActive کانفیگ فعال در ${buckets.size} کشور آماده اتصال فوری"
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun saveCachedPool(context: Context, snapshot: OrganizedPoolSnapshot) {
        try {
            val countriesArr = JSONArray()
            snapshot.countries.forEach { bucket ->
                val nodesArr = JSONArray()
                bucket.groups.forEach { grp ->
                    grp.nodes.forEach { rn ->
                        nodesArr.put(JSONObject().apply {
                            put("rawUri", rn.node.rawUri)
                            put("delayMs", rn.delayMs)
                        })
                    }
                }
                countriesArr.put(JSONObject().apply {
                    put("countryCode", bucket.countryCode)
                    put("nodes", nodesArr)
                })
            }
            val root = JSONObject().apply {
                put("updatedAtMs", snapshot.updatedAtMs)
                put("totalScanned", snapshot.totalScanned)
                put("countries", countriesArr)
            }
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_CACHED_POOL_JSON, root.toString())
                .apply()
        } catch (_: Exception) {
        }
    }

    /**
     * Scans all saved + GitHub configs, detects each server's country via batch GeoIP (with flag fallback),
     * benchmarks real latency via Libv2ray, discards dead ones, groups active configs by country,
     * chunks each country into ready-to-use groups of 5, and caches the result for instant START.
     */
    suspend fun scanAndOrganizeByCountry(
        context: Context,
        onlyCountryCode: String? = null,
        onProgress: suspend (stepText: String, percent: Int) -> Unit
    ): OrganizedPoolSnapshot = withContext(Dispatchers.IO) {
        Libv2ray.initCoreEnv(context.filesDir.absolutePath, "")

        onProgress("در حال خواندن کانفیگ‌ها...", 8)
        val combinedRaw = StringBuilder()
        val manual = getManualConfigs(context)
        if (manual.isNotBlank()) combinedRaw.append(manual).append("\n")
        val remote = fetchRemoteConfigs()
        if (remote.isNotBlank()) combinedRaw.append(remote).append("\n")

        val parsedNodes = ProxyConfigParser.parseBatch(combinedRaw.toString())
        if (parsedNodes.isEmpty()) {
            clearCache(context)
            return@withContext OrganizedPoolSnapshot(
                updatedAtMs = System.currentTimeMillis(),
                totalScanned = 0,
                totalActive = 0,
                countries = emptyList(),
                statusMessage = "هنوز کانفیگی وارد نشده! روی «مدیریت کانفیگ‌ها» بزنید و لینک‌ها را پیست کنید."
            )
        }

        onProgress("در حال تشخیص کشور ${parsedNodes.size} کانفیگ...", 18)
        val nodeCountryList = resolveCountriesBatch(parsedNodes)

        val candidates = if (onlyCountryCode != null) {
            nodeCountryList.filter { it.second.equals(onlyCountryCode, ignoreCase = true) }
        } else {
            nodeCountryList
        }

        if (candidates.isEmpty()) {
            clearCache(context)
            return@withContext OrganizedPoolSnapshot(
                updatedAtMs = System.currentTimeMillis(),
                totalScanned = parsedNodes.size,
                totalActive = 0,
                countries = emptyList(),
                statusMessage = "کانفیگی برای کشور انتخاب‌شده پیدا نشد."
            )
        }

        val total = candidates.size
        onProgress("در حال تست سرعت $total کانفیگ و دسته‌بندی ۵تایی...", 25)

        val semaphore = Semaphore(6)
        var completed = 0
        val lock = Any()

        val activeNodes = coroutineScope {
            candidates.map { (node, cc) ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val delayMs = measureNodeRealDelay(node)
                        val doneNow = synchronized(lock) {
                            completed++
                            completed
                        }
                        val pct = 25 + (doneNow * 72 / total)
                        onProgress("بررسی $doneNow از $total (${countryMeta(cc).first} ${node.protocol})...", pct)
                        if (delayMs in 1..4500) RankedProxyNode(node, delayMs, cc) else null
                    }
                }
            }.awaitAll().filterNotNull()
        }

        if (activeNodes.isEmpty()) {
            clearCache(context)
            return@withContext OrganizedPoolSnapshot(
                updatedAtMs = System.currentTimeMillis(),
                totalScanned = total,
                totalActive = 0,
                countries = emptyList(),
                statusMessage = "هیچ‌کدام از $total کانفیگ روی این اپراتور پاسخ ندادند؛ کانفیگ‌های جدیدتر وارد کنید."
            )
        }

        val groupedByCountry = activeNodes
            .groupBy { it.countryCode }
            .map { (cc, list) ->
                val sorted = list.sortedBy { it.delayMs }
                val groupsOf5 = sorted.chunked(5).mapIndexed { idx, chunk ->
                    ConfigGroup5(idx + 1, cc, chunk)
                }
                val (flag, persianName) = countryMeta(cc)
                CountryBucket(cc, flag, persianName, groupsOf5)
            }
            .sortedWith(
                compareByDescending<CountryBucket> { it.countryCode == "DE" }
                    .thenBy { it.bestPingMs }
            )

        val snapshot = OrganizedPoolSnapshot(
            updatedAtMs = System.currentTimeMillis(),
            totalScanned = total,
            totalActive = activeNodes.size,
            countries = groupedByCountry,
            statusMessage = "${activeNodes.size} سرور فعال از $total کانفیگ در ${groupedByCountry.size} کشور آماده اتصال فوری"
        )
        saveCachedPool(context, snapshot)
        snapshot
    }

    /**
     * Filters raw pasted configs to keep ONLY Germany (DE) links.
     */
    suspend fun filterGermanyOnly(rawText: String): Pair<List<ParsedProxyNode>, Int> = withContext(Dispatchers.IO) {
        val allNodes = ProxyConfigParser.parseBatch(rawText)
        if (allNodes.isEmpty()) return@withContext emptyList<ParsedProxyNode>() to 0
        val withCountry = resolveCountriesBatch(allNodes)
        val deOnly = withCountry.filter { it.second == "DE" }.map { it.first }
        deOnly to allNodes.size
    }

    private suspend fun resolveCountriesBatch(
        nodes: List<ParsedProxyNode>
    ): List<Pair<ParsedProxyNode, String>> = withContext(Dispatchers.IO) {
        val nodeIps = coroutineScope {
            nodes.map { node ->
                async(Dispatchers.IO) {
                    val ip = try {
                        InetAddress.getByName(node.host).hostAddress ?: node.host
                    } catch (_: Exception) {
                        node.host
                    }
                    node to ip
                }
            }.awaitAll()
        }

        val ipToCountry = mutableMapOf<String, String>()
        val uniqueIps = nodeIps.map { it.second }.distinct()
        uniqueIps.chunked(100).forEach { batch ->
            try {
                val arr = JSONArray()
                batch.forEach { arr.put(it) }
                val conn = (URL("http://ip-api.com/batch?fields=query,countryCode").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 5000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                conn.outputStream.use { it.write(arr.toString().toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val respArr = JSONArray(body)
                    for (i in 0 until respArr.length()) {
                        val obj = respArr.optJSONObject(i) ?: continue
                        val q = obj.optString("query", "")
                        val cc = obj.optString("countryCode", "")
                        if (q.isNotBlank() && cc.length == 2) {
                            ipToCountry[q] = cc.uppercase()
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
            }
        }

        nodeIps.map { (node, ip) ->
            val cc = ipToCountry[ip] ?: inferCountryFromLabel(node.label)
            node to cc
        }
    }

    private fun inferCountryFromLabel(label: String): String {
        val flagMap = listOf(
            "🇩🇪" to "DE", "🇳🇱" to "NL", "🇵🇱" to "PL", "🇫🇮" to "FI",
            "🇫🇷" to "FR", "🇬🇧" to "GB", "🇺🇸" to "US", "🇦🇹" to "AT",
            "🇸🇪" to "SE", "🇨🇭" to "CH", "🇹🇷" to "TR", "🇮🇹" to "IT",
            "🇪🇸" to "ES", "🇨🇦" to "CA", "🇸🇬" to "SG", "🇷🇺" to "RU",
            "🇳🇴" to "NO", "🇨🇿" to "CZ", "🇷🇴" to "RO", "🇺🇦" to "UA"
        )
        for ((flag, code) in flagMap) {
            if (label.contains(flag)) return code
        }
        val lower = label.lowercase()
        return when {
            lower.contains("germany") || lower.contains("frankfurt") || Regex("\\bde\\b").containsMatchIn(lower) -> "DE"
            lower.contains("netherlands") || lower.contains("amsterdam") || Regex("\\bnl\\b").containsMatchIn(lower) -> "NL"
            lower.contains("poland") || lower.contains("warsaw") || Regex("\\bpl\\b").containsMatchIn(lower) -> "PL"
            lower.contains("finland") || lower.contains("helsinki") || Regex("\\bfi\\b").containsMatchIn(lower) -> "FI"
            lower.contains("france") || lower.contains("paris") || Regex("\\bfr\\b").containsMatchIn(lower) -> "FR"
            lower.contains("united kingdom") || lower.contains("london") || Regex("\\b(uk|gb)\\b").containsMatchIn(lower) -> "GB"
            lower.contains("austria") || lower.contains("vienna") || Regex("\\bat\\b").containsMatchIn(lower) -> "AT"
            lower.contains("sweden") || lower.contains("stockholm") || Regex("\\bse\\b").containsMatchIn(lower) -> "SE"
            lower.contains("switzerland") || lower.contains("zurich") || Regex("\\bch\\b").containsMatchIn(lower) -> "CH"
            lower.contains("turkey") || lower.contains("istanbul") || Regex("\\btr\\b").containsMatchIn(lower) -> "TR"
            lower.contains("usa") || lower.contains("united states") || Regex("\\bus\\b").containsMatchIn(lower) -> "US"
            else -> "UN"
        }
    }

    fun countryMeta(code: String): Pair<String, String> {
        return when (code.uppercase()) {
            "DE" -> "🇩🇪" to "آلمان"
            "NL" -> "🇳🇱" to "هلند"
            "PL" -> "🇵🇱" to "لهستان"
            "FI" -> "🇫🇮" to "فنلاند"
            "FR" -> "🇫🇷" to "فرانسه"
            "AT" -> "🇦🇹" to "اتریش"
            "GB", "UK" -> "🇬🇧" to "انگلیس"
            "SE" -> "🇸🇪" to "سوئد"
            "CH" -> "🇨🇭" to "سوئیس"
            "IT" -> "🇮🇹" to "ایتالیا"
            "ES" -> "🇪🇸" to "اسپانیا"
            "CZ" -> "🇨🇿" to "چک"
            "RO" -> "🇷🇴" to "رومانی"
            "NO" -> "🇳🇴" to "نروژ"
            "TR" -> "🇹🇷" to "ترکیه"
            "US" -> "🇺🇸" to "آمریکا"
            "CA" -> "🇨🇦" to "کانادا"
            "SG" -> "🇸🇬" to "سنگاپور"
            "RU" -> "🇷🇺" to "روسیه"
            "UA" -> "🇺🇦" to "اوکراین"
            "UN" -> "🌍" to "سایر"
            else -> codeToFlagEmoji(code) to code.uppercase()
        }
    }

    private fun codeToFlagEmoji(code: String): String {
        if (code.length != 2) return "🌍"
        val upper = code.uppercase()
        val first = Character.codePointAt(upper, 0) - 0x41 + 0x1F1E6
        val second = Character.codePointAt(upper, 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(first)) + String(Character.toChars(second))
    }

    private fun measureNodeRealDelay(node: ParsedProxyNode): Int {
        return try {
            val testJson = ProxyConfigParser.buildSingleTestConfig(node)
            val ms = Libv2ray.measureOutboundDelay(testJson, "https://www.gstatic.com/generate_204")
            if (ms > 0L) ms.toInt() else -1
        } catch (_: Throwable) {
            -1
        }
    }

    private fun fetchRemoteConfigs(): String {
        return try {
            val conn = (URL(REMOTE_GUILD_CONFIGS_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4500
                readTimeout = 4500
                setRequestProperty("User-Agent", "AlbionGuard-Android")
            }
            if (conn.responseCode == 200) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                text
            } else {
                conn.disconnect()
                ""
            }
        } catch (_: Exception) {
            ""
        }
    }
}
