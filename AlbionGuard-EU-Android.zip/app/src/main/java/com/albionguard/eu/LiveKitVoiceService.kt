package com.albionguard.eu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import io.livekit.android.LiveKit
import io.livekit.android.RoomOptions
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.room.Room
import io.livekit.android.room.participant.AudioPresets
import io.livekit.android.room.participant.AudioTrackPublishDefaults
import io.livekit.android.room.track.LocalAudioTrackOptions
import io.livekit.android.room.track.RemoteAudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class VoiceMember(
    val identity: String,
    val displayName: String,
    val isLocal: Boolean,
    val isSpeaking: Boolean,
    val isMuted: Boolean
)

enum class VoiceConnStatus {
    IDLE,
    CONNECTING,
    CONNECTED,
    ERROR
}

data class VoiceUiState(
    val status: VoiceConnStatus = VoiceConnStatus.IDLE,
    val roomCode: String = "",
    val isMicMuted: Boolean = false,
    val isRoomDeafened: Boolean = false,
    val members: List<VoiceMember> = emptyList(),
    val errorMessage: String = ""
)

class LiveKitVoiceService : Service() {

    companion object {
        const val ACTION_JOIN = "com.albionguard.eu.LK_JOIN"
        const val ACTION_LEAVE = "com.albionguard.eu.LK_LEAVE"
        const val ACTION_TOGGLE_MUTE = "com.albionguard.eu.LK_TOGGLE_MUTE"
        const val ACTION_TOGGLE_DEAFEN = "com.albionguard.eu.LK_TOGGLE_DEAFEN"
        const val EXTRA_ROOM_CODE = "extra_room_code"
        const val EXTRA_DISPLAY_NAME = "extra_display_name"

        private const val CHANNEL_ID = "albion_livekit_voice"
        private const val NOTIF_ID = 7073

        private val _state = MutableStateFlow(VoiceUiState())
        val state: StateFlow<VoiceUiState> = _state.asStateFlow()

        fun sanitizeRoomCode(raw: String): String {
            val cleaned = raw.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
            return if (cleaned.length >= 3) cleaned else "albion-iran"
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var room: Room? = null
    private var eventsJob: Job? = null
    private var activeSpeakerIds: Set<String> = emptySet()
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LEAVE -> {
                leaveRoom()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_MUTE -> {
                toggleMicMute()
                return START_STICKY
            }
            ACTION_TOGGLE_DEAFEN -> {
                toggleRoomDeafen()
                return START_STICKY
            }
            else -> {
                val roomCode = sanitizeRoomCode(intent?.getStringExtra(EXTRA_ROOM_CODE) ?: "albion-iran")
                val name = (intent?.getStringExtra(EXTRA_DISPLAY_NAME) ?: "").trim().ifBlank { Build.MODEL }
                joinRoom(roomCode, name)
                return START_STICKY
            }
        }
    }

    private fun joinRoom(roomCode: String, displayName: String) {
        val wsUrl = BuildConfig.LIVEKIT_URL.trim()
        val apiKey = BuildConfig.LIVEKIT_API_KEY.trim()
        val apiSecret = BuildConfig.LIVEKIT_API_SECRET.trim()

        if (wsUrl.isBlank() || apiKey.isBlank() || apiSecret.isBlank()) {
            _state.value = VoiceUiState(
                status = VoiceConnStatus.ERROR,
                roomCode = roomCode,
                errorMessage = "کلیدهای LiveKit در GitHub Secrets تنظیم نشده‌اند."
            )
            stopSelf()
            return
        }

        createNotificationChannel()
        acquireLocks()
        _state.value = VoiceUiState(
            status = VoiceConnStatus.CONNECTING,
            roomCode = roomCode
        )
        startForeground(NOTIF_ID, buildNotification("در حال اتصال به اتاق $roomCode..."))

        serviceScope.launch {
            try {
                cleanupRoomOnly()

                val uniqueId = "${displayName}_${UUID.randomUUID().toString().take(5)}"
                val token = LiveKitTokenGenerator.createJoinToken(
                    apiKey = apiKey,
                    apiSecret = apiSecret,
                    roomName = "albion-$roomCode",
                    identity = uniqueId,
                    displayName = displayName
                )

                // Tuned Gaming Speech Profile:
                // 1) SPEECH preset (24kbps instead of default 48kbps MUSIC) -> lower latency & upload load
                // 2) dtx = false -> prevents choppy word-start/word-end clipping
                // 3) red = true -> Opus Redundant Audio Data recovers dropped UDP packets smoothly
                // 4) Full hardware DSP: noise suppression + echo cancellation + auto gain + high-pass filter
                val roomOptions = RoomOptions(
                    audioTrackCaptureDefaults = LocalAudioTrackOptions(
                        noiseSuppression = true,
                        echoCancellation = true,
                        autoGainControl = true,
                        highPassFilter = true,
                        typingNoiseDetection = true
                    ),
                    audioTrackPublishDefaults = AudioTrackPublishDefaults(
                        audioBitrate = AudioPresets.SPEECH.maxBitrate,
                        dtx = false,
                        red = true
                    )
                )

                val lkRoom = LiveKit.create(
                    appContext = applicationContext,
                    options = roomOptions
                )
                room = lkRoom

                eventsJob = serviceScope.launch {
                    lkRoom.events.collect { event ->
                        when (event) {
                            is RoomEvent.ParticipantConnected -> {
                                playTone(ToneGenerator.TONE_PROP_BEEP)
                                refreshMembers()
                            }
                            is RoomEvent.ParticipantDisconnected -> {
                                playTone(ToneGenerator.TONE_PROP_NACK)
                                refreshMembers()
                            }
                            is RoomEvent.TrackSubscribed -> {
                                val track = event.track
                                if (track is RemoteAudioTrack && _state.value.isRoomDeafened) {
                                    track.setVolume(0.0)
                                }
                                refreshMembers()
                            }
                            is RoomEvent.TrackMuted,
                            is RoomEvent.TrackUnmuted -> {
                                refreshMembers()
                            }
                            is RoomEvent.ActiveSpeakersChanged -> {
                                activeSpeakerIds = event.speakers.mapNotNull { it.identity?.value }.toSet()
                                refreshMembers()
                            }
                            is RoomEvent.Disconnected -> {
                                if (_state.value.status == VoiceConnStatus.CONNECTED) {
                                    _state.value = VoiceUiState(
                                        status = VoiceConnStatus.ERROR,
                                        roomCode = roomCode,
                                        errorMessage = "اتصال ویس قطع شد؛ دوباره وارد شوید."
                                    )
                                    releaseLocks()
                                    stopForeground(STOP_FOREGROUND_REMOVE)
                                    stopSelf()
                                }
                            }
                            else -> {}
                        }
                    }
                }

                lkRoom.connect(url = wsUrl, token = token)
                lkRoom.localParticipant.setMicrophoneEnabled(true)

                _state.value = _state.value.copy(
                    status = VoiceConnStatus.CONNECTED,
                    roomCode = roomCode,
                    isMicMuted = false,
                    isRoomDeafened = false,
                    errorMessage = ""
                )
                playTone(ToneGenerator.TONE_PROP_BEEP)
                refreshMembers()
                updateNotification()
            } catch (e: Exception) {
                cleanupRoomOnly()
                releaseLocks()
                _state.value = VoiceUiState(
                    status = VoiceConnStatus.ERROR,
                    roomCode = roomCode,
                    errorMessage = "اتصال ناموفق: ${e.localizedMessage ?: "خطای شبکه"}"
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun toggleMicMute() {
        val lkRoom = room ?: return
        val newMuted = !_state.value.isMicMuted
        serviceScope.launch {
            try {
                lkRoom.localParticipant.setMicrophoneEnabled(!newMuted)
                _state.value = _state.value.copy(isMicMuted = newMuted)
                refreshMembers()
                updateNotification()
            } catch (_: Exception) {
            }
        }
    }

    private fun toggleRoomDeafen() {
        val lkRoom = room ?: return
        val newDeafened = !_state.value.isRoomDeafened
        val targetVol = if (newDeafened) 0.0 else 1.0

        lkRoom.remoteParticipants.values.forEach { participant ->
            participant.audioTrackPublications.forEach { (_, track) ->
                if (track is RemoteAudioTrack) {
                    track.setVolume(targetVol)
                }
            }
        }

        _state.value = _state.value.copy(isRoomDeafened = newDeafened)
        updateNotification()
    }

    private fun refreshMembers() {
        val lkRoom = room ?: return
        val list = mutableListOf<VoiceMember>()

        val local = lkRoom.localParticipant
        val localId = local.identity?.value ?: "me"
        val localName = (local.name ?: "").ifBlank { "شما" }
        list.add(
            VoiceMember(
                identity = localId,
                displayName = "$localName (شما)",
                isLocal = true,
                isSpeaking = activeSpeakerIds.contains(localId),
                isMuted = _state.value.isMicMuted
            )
        )

        lkRoom.remoteParticipants.values.forEach { rp ->
            val rId = rp.identity?.value ?: rp.sid.value
            val rName = (rp.name ?: "").ifBlank { rId.substringBefore("_") }
            val muted = !rp.isMicrophoneEnabled()
            list.add(
                VoiceMember(
                    identity = rId,
                    displayName = rName,
                    isLocal = false,
                    isSpeaking = activeSpeakerIds.contains(rId),
                    isMuted = muted
                )
            )
        }

        _state.value = _state.value.copy(members = list)
        updateNotification()
    }

    private fun leaveRoom() {
        cleanupRoomOnly()
        releaseLocks()
        _state.value = VoiceUiState(status = VoiceConnStatus.IDLE)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanupRoomOnly() {
        eventsJob?.cancel()
        eventsJob = null
        activeSpeakerIds = emptySet()
        try {
            room?.disconnect()
            room?.release()
        } catch (_: Exception) {
        }
        room = null
    }

    private fun acquireLocks() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(lockMode, "AlbionGuard::VoiceWifiLock").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        } catch (_: Exception) {
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlbionGuard::VoiceWakeLock").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) wakeLock?.acquire(4 * 60 * 60 * 1000L)
        } catch (_: Exception) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
    }

    private fun playTone(toneType: Int) {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            tg.startTone(toneType, 140)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        cleanupRoomOnly()
        releaseLocks()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "اتاق ویس گیلد",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "کنترل سریع ویس گیلد در پس‌زمینه بازی"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun updateNotification() {
        val st = _state.value
        val count = st.members.size.coerceAtLeast(1)
        val micTxt = if (st.isMicMuted) "میوت 🔇" else "باز 🎙️"
        val deafTxt = if (st.isRoomDeafened) " • سکوت اتاق" else ""
        val text = "اتاق ${st.roomCode} ($count نفر) • میکروفون: $micTxt$deafTxt"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            20,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val muteIntent = PendingIntent.getService(
            this,
            21,
            Intent(this, LiveKitVoiceService::class.java).apply { action = ACTION_TOGGLE_MUTE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val deafenIntent = PendingIntent.getService(
            this,
            22,
            Intent(this, LiveKitVoiceService::class.java).apply { action = ACTION_TOGGLE_DEAFEN },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val leaveIntent = PendingIntent.getService(
            this,
            23,
            Intent(this, LiveKitVoiceService::class.java).apply { action = ACTION_LEAVE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val muteLabel = if (_state.value.isMicMuted) "وصل من" else "میوت من"
        val deafLabel = if (_state.value.isRoomDeafened) "وصل اتاق" else "سکوت اتاق"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("Albion Guard • ویس گیلد")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_btn_speak_now, muteLabel, muteIntent)
            .addAction(android.R.drawable.ic_lock_silent_mode, deafLabel, deafenIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "خروج", leaveIntent)
            .build()
    }
}
