package com.albionguard.eu

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.telephony.TelephonyManager

data class DeviceNetworkProfile(
    val deviceLabel: String,
    val manufacturer: String,
    val networkType: String,
    val isWifi: Boolean,
    val carrierName: String,
    val isBatteryUnrestricted: Boolean,
    val isPrivateDnsHostnameActive: Boolean,
    val privateDnsSpecifier: String,
    val isAlbionInstalled: Boolean
)

object NetworkProfiler {

    const val ALBION_PACKAGE = "com.albiononline"

    fun inspect(context: Context): DeviceNetworkProfile {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNet = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(activeNet)

        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

        val networkType = when {
            isWifi -> "وای‌فای (Wi-Fi)"
            isCellular -> "دیتای موبایل (4G/5G)"
            else -> "عدم اتصال شبکه"
        }

        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val rawCarrier = (tm.networkOperatorName ?: "").trim()
        val carrierName = when {
            isWifi -> "مودم / وای‌فای"
            rawCarrier.contains("MCI", ignoreCase = true) ||
                rawCarrier.contains("Hamrah", ignoreCase = true) ||
                rawCarrier.contains("43211") -> "همراه اول (IR-MCI)"
            rawCarrier.contains("Irancell", ignoreCase = true) ||
                rawCarrier.contains("MTN", ignoreCase = true) ||
                rawCarrier.contains("43235") -> "ایرانسل (MTN Irancell)"
            rawCarrier.contains("Rightel", ignoreCase = true) ||
                rawCarrier.contains("43220") -> "رایتل (Rightel)"
            rawCarrier.isNotBlank() -> rawCarrier
            else -> "اپراتور موبایل"
        }

        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val isBatteryUnrestricted = pm.isIgnoringBatteryOptimizations(context.packageName)

        val privateDnsMode = try {
            Settings.Global.getString(context.contentResolver, "private_dns_mode") ?: "opportunistic"
        } catch (_: Exception) {
            "unknown"
        }
        val privateDnsSpecifier = try {
            Settings.Global.getString(context.contentResolver, "private_dns_specifier") ?: ""
        } catch (_: Exception) {
            ""
        }
        val isPrivateDnsHostnameActive = privateDnsMode.equals("hostname", ignoreCase = true)

        val isAlbionInstalled = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    ALBION_PACKAGE,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(ALBION_PACKAGE, 0)
            }
            true
        } catch (_: Exception) {
            false
        }

        val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL

        return DeviceNetworkProfile(
            deviceLabel = "$brand $model",
            manufacturer = Build.MANUFACTURER.lowercase(),
            networkType = networkType,
            isWifi = isWifi,
            carrierName = carrierName,
            isBatteryUnrestricted = isBatteryUnrestricted,
            isPrivateDnsHostnameActive = isPrivateDnsHostnameActive,
            privateDnsSpecifier = privateDnsSpecifier,
            isAlbionInstalled = isAlbionInstalled
        )
    }
}
