package com.albionguard.eu

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

data class DeviceNetworkProfile(
    val deviceLabel: String,
    val manufacturer: String,
    val networkType: String,
    val isWifi: Boolean,
    val carrierName: String,
    val isBatteryUnrestricted: Boolean,
    val isPrivateDnsHostnameActive: Boolean,
    val privateDnsSpecifier: String,
    val isAlbionInstalled: Boolean
)

object NetworkProfiler {

    const val ALBION_PACKAGE = "com.albiononline"

    fun inspect(context: Context): DeviceNetworkProfile {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // Inspect underlying non-VPN networks so our own local DNS VpnService never hides Wi-Fi/LTE
        var isWifi = false
        var isCellular = false

        @Suppress("DEPRECATION")
        val allNetworks = cm.allNetworks
        for (net in allNetworks) {
            val caps = cm.getNetworkCapabilities(net) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                isWifi = true
                break
            }
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                isCellular = true
            }
        }

        // Fallback to activeNetwork if allNetworks returned nothing
        if (!isWifi && !isCellular) {
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        }

        val networkType = when {
            isWifi -> "وای‌فای (Wi-Fi)"
            isCellular -> "دیتای موبایل (4G/5G)"
            else -> "عدم اتصال شبکه"
        }

        val carrierName = if (isWifi) {
            "مودم / وای‌فای"
        } else {
            detectActiveDataCarrier(context)
        }

        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val isBatteryUnrestricted = pm.isIgnoringBatteryOptimizations(context.packageName)

        val privateDnsMode = try {
            Settings.Global.getString(context.contentResolver, "private_dns_mode") ?: "opportunistic"
        } catch (_: Exception) {
            "unknown"
        }
        val privateDnsSpecifier = try {
            Settings.Global.getString(context.contentResolver, "private_dns_specifier") ?: ""
        } catch (_: Exception) {
            ""
        }
        val isPrivateDnsHostnameActive = privateDnsMode.equals("hostname", ignoreCase = true)

        val isAlbionInstalled = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    ALBION_PACKAGE,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(ALBION_PACKAGE, 0)
            }
            true
        } catch (_: Exception) {
            false
        }

        val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL

        return DeviceNetworkProfile(
            deviceLabel = "$brand $model",
            manufacturer = Build.MANUFACTURER.lowercase(),
            networkType = networkType,
            isWifi = isWifi,
            carrierName = carrierName,
            isBatteryUnrestricted = isBatteryUnrestricted,
            isPrivateDnsHostnameActive = isPrivateDnsHostnameActive,
            privateDnsSpecifier = privateDnsSpecifier,
            isAlbionInstalled = isAlbionInstalled
        )
    }

    /**
     * Reads the active DATA SIM's carrier name & MCC/MNC on Dual-SIM Android devices
     * (fixes showing SIM 1 Irancell when mobile data is actually on SIM 2 Hamrah-e Aval).
     */
    private fun detectActiveDataCarrier(context: Context): String {
        val baseTm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val dataSubId = SubscriptionManager.getDefaultDataSubscriptionId()
        val dataTm = if (dataSubId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            baseTm.createForSubscriptionId(dataSubId)
        } else {
            baseTm
        }

        val opName = (dataTm.networkOperatorName ?: "").trim()
        val opCode = (dataTm.networkOperator ?: "").trim()
        val combined = "$opName $opCode"

        return when {
            opCode == "43211" ||
                combined.contains("MCI", ignoreCase = true) ||
                combined.contains("Hamrah", ignoreCase = true) ||
                combined.contains("TCI", ignoreCase = true) -> "همراه اول (IR-MCI)"
            opCode == "43235" ||
                combined.contains("Irancell", ignoreCase = true) ||
                combined.contains("MTN", ignoreCase = true) -> "ایرانسل (MTN Irancell)"
            opCode == "43220" ||
                combined.contains("Rightel", ignoreCase = true) -> "رایتل (Rightel)"
            opCode == "43214" ||
                combined.contains("Kish", ignoreCase = true) -> "تله‌کیش / شاتل‌موبایل"
            opName.isNotBlank() -> opName
            else -> "اپراتور موبایل"
        }
    }
}
