package com.albionguard.eu

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import java.net.URLEncoder

data class VoiceServer(
    val id: String,
    val label: String,
    val baseUrl: String
)

object VoiceRoomHelper {

    val SERVERS = listOf(
        VoiceServer("ffmuc", "آلمان (پیشنهادی)", "https://meet.ffmuc.net"),
        VoiceServer("element", "اروپا ۲ (پشتیبان)", "https://meet.element.io"),
        VoiceServer("evolix", "فرانسه (پشتیبان)", "https://meet.evolix.org")
    )

    fun sanitizeRoomCode(raw: String): String {
        val cleaned = raw.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
        return if (cleaned.length >= 3) cleaned else "albion-iran"
    }

    /**
     * Builds the Jitsi Audio-Only URL.
     * - autoJoin = true (for app users who already typed their nickname): joins immediately with their exact name.
     * - autoJoin = false (for copied friend/laptop link): shows quick name prompt so friends enter their own name.
     * - disableJoinLeaveSounds = false: plays a clear chime whenever someone joins or leaves, even in background!
     */
    fun buildVoiceRoomUrl(
        server: VoiceServer,
        roomCode: String,
        displayName: String = Build.MODEL,
        autoJoin: Boolean = true
    ): String {
        val cleanRoom = sanitizeRoomCode(roomCode)
        val cleanName = displayName.trim().ifBlank { Build.MODEL }
        val encodedName = try {
            URLEncoder.encode(cleanName, "UTF-8").replace("+", "%20")
        } catch (_: Exception) {
            "Player"
        }

        val prejoinFlag = if (autoJoin) "false" else "true"
        val userInfoParam = if (autoJoin) "&userInfo.displayName=%22$encodedName%22" else ""

        return "${server.baseUrl}/AlbionGuard-$cleanRoom" +
            "#config.startAudioOnly=true" +
            "&config.startWithVideoMuted=true" +
            "&config.startWithAudioMuted=false" +
            "&config.prejoinPageEnabled=$prejoinFlag" +
            "&config.prejoinConfig.enabled=$prejoinFlag" +
            "&config.disableDeepLinking=true" +
            "&config.disableJoinLeaveSounds=false" +
            "&config.p2p.enabled=false" +
            "&config.audioQuality.stereo=false" +
            "&config.audioQuality.opusMaxAverageBitrate=24000" +
            "&interfaceConfig.MOBILE_APP_PROMO=false" +
            userInfoParam
    }

    fun openInChromeCustomTab(context: Context, url: String) {
        val colorParams = CustomTabColorSchemeParams.Builder()
            .setToolbarColor(Color.parseColor("#080B12"))
            .setNavigationBarColor(Color.parseColor("#080B12"))
            .build()

        val customTabsIntent = CustomTabsIntent.Builder()
            .setDefaultColorSchemeParams(colorParams)
            .setShowTitle(true)
            .setUrlBarHidingEnabled(true)
            .build()

        try {
            customTabsIntent.launchUrl(context, Uri.parse(url))
        } catch (_: Exception) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
}

object VoiceAudioController {

    @Volatile
    var isMicMuted: Boolean = false
        private set

    @Volatile
    var isRoomDeafened: Boolean = false
        private set

    private var savedVoiceVolume: Int = -1

    fun toggleMicMute(context: Context): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        isMicMuted = !isMicMuted
        try {
            am.isMicrophoneMute = isMicMuted
        } catch (_: Exception) {
        }
        return isMicMuted
    }

    fun toggleRoomDeafen(context: Context): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        isRoomDeafened = !isRoomDeafened
        try {
            if (isRoomDeafened) {
                savedVoiceVolume = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
                am.adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, AudioManager.ADJUST_MUTE, 0)
                val minVol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    am.getStreamMinVolume(AudioManager.STREAM_VOICE_CALL)
                } else {
                    0
                }
                am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, minVol, 0)
            } else {
                am.adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, AudioManager.ADJUST_UNMUTE, 0)
                if (savedVoiceVolume > 0) {
                    am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, savedVoiceVolume, 0)
                }
            }
        } catch (_: Exception) {
        }
        return isRoomDeafened
    }
}
