package com.albionguard.eu

import android.content.Context
import android.media.AudioManager
import android.os.Build
import org.jitsi.meet.sdk.JitsiMeetActivity
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import org.jitsi.meet.sdk.JitsiMeetUserInfo
import java.net.URL
import java.net.URLEncoder

data class VoiceServer(
    val id: String,
    val label: String,
    val baseUrl: String
)

object VoiceRoomHelper {

    // France (meet.evolix.org) is #1 default — verified working on both MobinNet Wi-Fi & Hamrah-e Aval!
    val SERVERS = listOf(
        VoiceServer("evolix", "فرانسه (پیشنهادی)", "https://meet.evolix.org"),
        VoiceServer("ffmuc", "آلمان (همراه اول)", "https://meet.ffmuc.net")
    )

    fun sanitizeRoomCode(raw: String): String {
        val cleaned = raw.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
        return if (cleaned.length >= 3) cleaned else "albion-iran"
    }

    /**
     * Launches the NATIVE in-app Jitsi Voice Room directly inside Albion Guard (NO Chrome!).
     * Stays 100% alive in the background while playing Albion Online via Jitsi's native call service.
     */
    fun launchNativeVoiceRoom(
        context: Context,
        server: VoiceServer,
        roomCode: String,
        displayName: String
    ) {
        val cleanRoom = "AlbionGuard-${sanitizeRoomCode(roomCode)}"
        val cleanName = displayName.trim().ifBlank { Build.MODEL }

        val userInfo = JitsiMeetUserInfo().apply {
            this.displayName = cleanName
        }

        val options = JitsiMeetConferenceOptions.Builder()
            .setServerURL(URL(server.baseUrl))
            .setRoom(cleanRoom)
            .setUserInfo(userInfo)
            .setAudioOnly(true)
            .setVideoMuted(true)
            .setAudioMuted(false)
            .setConfigOverride("startAudioOnly", true)
            .setConfigOverride("startWithVideoMuted", true)
            .setConfigOverride("prejoinPageEnabled", false)
            .setConfigOverride("p2p.enabled", false)
            .setConfigOverride("disableJoinLeaveSounds", false)
            .setConfigOverride("audioQuality.stereo", false)
            .setConfigOverride("audioQuality.opusMaxAverageBitrate", 24000)
            .setFeatureFlag("welcomepage.enabled", false)
            .setFeatureFlag("prejoinpage.enabled", false)
            .setFeatureFlag("pip.enabled", false)
            .setFeatureFlag("invite.enabled", false)
            .setFeatureFlag("video-mute.enabled", false)
            .setFeatureFlag("filmstrip.enabled", true)
            .setFeatureFlag("call-integration.enabled", false)
            .setFeatureFlag("notifications.enabled", true)
            .build()

        JitsiMeetActivity.launch(context, options)
    }

    /**
     * Shareable URL for laptop friends (opens in Chrome) or phone friends with Albion Guard (Deep Link).
     */
    fun buildShareableUrl(server: VoiceServer, roomCode: String): String {
        val cleanRoom = sanitizeRoomCode(roomCode)
        return "${server.baseUrl}/AlbionGuard-$cleanRoom" +
            "#config.startAudioOnly=true" +
            "&config.startWithVideoMuted=true" +
            "&config.startWithAudioMuted=false" +
            "&config.prejoinPageEnabled=true" +
            "&config.disableDeepLinking=true" +
            "&config.disableJoinLeaveSounds=false" +
            "&config.p2p.enabled=false" +
            "&config.audioQuality.opusMaxAverageBitrate=24000"
    }
}

object VoiceAudioController {

    @Volatile
    var isMicMuted: Boolean = false
        private set

    @Volatile
    var isRoomDeafened: Boolean = false
        private set

    private var savedVoiceVolume: Int = -1

    fun toggleMicMute(context: Context): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        isMicMuted = !isMicMuted
        try {
            am.isMicrophoneMute = isMicMuted
        } catch (_: Exception) {
        }
        return isMicMuted
    }

    fun toggleRoomDeafen(context: Context): Boolean {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        isRoomDeafened = !isRoomDeafened
        try {
            if (isRoomDeafened) {
                savedVoiceVolume = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
                am.adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, AudioManager.ADJUST_MUTE, 0)
                val minVol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    am.getStreamMinVolume(AudioManager.STREAM_VOICE_CALL)
                } else {
                    0
                }
                am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, minVol, 0)
            } else {
                am.adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, AudioManager.ADJUST_UNMUTE, 0)
                if (savedVoiceVolume > 0) {
                    am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, savedVoiceVolume, 0)
                }
            }
        } catch (_: Exception) {
        }
        return isRoomDeafened
    }
}
