package com.albionguard.eu

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

data class DnsPreset(
    val id: String,
    val name: String,
    val primary: String,
    val secondary: String,
    val note: String
)

data class DnsProbeResult(
    val preset: DnsPreset,
    val dnsReachable: Boolean,
    val resolvedIp: String?,
    val dnsLatencyMs: Int,
    val isSinkholed: Boolean
)

enum class ReadinessLevel {
    READY,
    CAUTION,
    NEEDS_TUNNEL
}

data class AuditReport(
    val selectedDns: DnsPreset,
    val backupDns: DnsPreset?,
    val topWorkingDns: List<DnsProbeResult>,
    val avgPingMs: Int,
    val maxSpikeMs: Int,
    val jitterMs: Int,
    val packetLossPct: Int,
    val dnsLatencyMs: Int,
    val readiness: ReadinessLevel,
    val summaryTitle: String,
    val summaryDetail: String,
    val testedCount: Int
)

object AlbionAuditEngine {

    val DNS_PRESETS = listOf(
        DnsPreset("shecan", "شکن (Shecan)", "178.22.122.100", "185.51.200.2", "پایدار روی همراه اول و وای‌فای"),
        DnsPreset("begzar", "بگذر (Begzar)", "185.55.226.26", "185.55.225.25", "سریع روی مبین‌نت"),
        DnsPreset("radar", "رادار گیم (Radar)", "10.202.10.10", "10.202.10.11", "مخصوص گیم در ایران"),
        DnsPreset("electro", "الکترو (Electro)", "78.157.42.100", "78.157.42.101", "رفع تحریم گیمینگ"),
        DnsPreset("403", "۴۰۳ آنلاین (403)", "10.202.10.202", "10.202.10.102", "مناسب همراه اول و ایرانسل"),
        DnsPreset("cloudflare", "کلودفلر (1.1.1.1)", "1.1.1.1", "1.0.0.1", "DNS سریع جهانی"),
        DnsPreset("google", "گوگل (8.8.8.8)", "8.8.8.8", "8.8.4.4", "پایداری بین‌المللی")
    )

    // Probe the actual Albion Online live domain on UDP-53 to catch ISP sinkholes accurately
    private const val DNS_QUERY_DOMAIN = "live.albiononline.com"
    private val EU_PROBE_HOSTS = listOf(
        "dynamodb.eu-central-1.amazonaws.com" to 443,
        "live.albiononline.com" to 443,
        "albiononline.com" to 443
    )

    suspend fun runFullAudit(
        onProgress: suspend (stepText: String, percent: Int) -> Unit
    ): AuditReport = withContext(Dispatchers.IO) {
        onProgress("در حال تست ۷ سرور DNS روی دامنه واقعی آلبیون...", 15)

        val dnsResults = mutableListOf<DnsProbeResult>()
        DNS_PRESETS.forEachIndexed { idx, preset ->
            val progress = 15 + ((idx + 1) * 40 / DNS_PRESETS.size)
            onProgress("تست ${preset.name}...", progress)
            // Take the better of 2 quick probes so a single random packet drop doesn't disqualify a great DNS
            val r1 = probeDnsUdp53(preset)
            val r2 = if (!r1.dnsReachable || r1.dnsLatencyMs > 120) probeDnsUdp53(preset) else r1
            val best = when {
                r1.dnsReachable && !r1.isSinkholed && r2.dnsReachable && !r2.isSinkholed ->
                    if (r1.dnsLatencyMs <= r2.dnsLatencyMs) r1 else r2
                r1.dnsReachable && !r1.isSinkholed -> r1
                else -> r2
            }
            dnsResults.add(best)
        }

        val cleanWorking = dnsResults
            .filter { it.dnsReachable && !it.isSinkholed && !it.resolvedIp.isNullOrBlank() }
            .sortedBy { it.dnsLatencyMs }

        val bestDnsResult = cleanWorking.firstOrNull()
        val chosenPreset = bestDnsResult?.preset ?: DNS_PRESETS.first()
        val backupPreset = cleanWorking.getOrNull(1)?.preset

        onProgress("در حال سنجش ثبات و اسپایک سرور اروپا (۱۰ تست)...", 60)

        val rtts = mutableListOf<Int>()
        val totalProbes = 10
        val targetHost = resolveBestEuProbeHost(bestDnsResult?.resolvedIp)

        for (i in 1..totalProbes) {
            onProgress("سنجش ثبات Black Zone ($i از $totalProbes)...", 60 + (i * 3))
            val rtt = measureTcpRtt(targetHost.first, targetHost.second, timeoutMs = 1500)
            if (rtt != null) {
                rtts.add(rtt)
            }
        }

        val received = rtts.size
        val lossPct = (((totalProbes - received).toDouble() / totalProbes) * 100.0).roundToInt()
        val avgPing = if (rtts.isNotEmpty()) rtts.average().roundToInt() else 999
        val maxSpike = rtts.maxOrNull() ?: 999
        val jitter = calculateJitter(rtts)

        onProgress("قفل کردن ۳ DNS برتر بدون قطعی...", 98)

        val (readiness, title, detail) = when {
            bestDnsResult == null || received == 0 -> Triple(
                ReadinessLevel.NEEDS_TUNNEL,
                "مسیر مستقیم روی این نت بسته است",
                "هیچ‌کدام از DNSها به سرور اروپا وصل نشدند. روی این نت به تونل UDP نیاز است."
            )
            lossPct >= 20 || jitter > 45 || maxSpike > 380 -> Triple(
                ReadinessLevel.CAUTION,
                "هشدار نوسان (احتیاط در Black Zone)",
                "میانگین پینگ ${avgPing}ms ولی اوج نوسان ${maxSpike}ms و جیتر ${jitter}ms است. آپلود پس‌زمینه مودم/گوشی را ببندید یا روی سیم‌کارت تست کنید."
            )
            else -> Triple(
                ReadinessLevel.READY,
                "امن برای Black Zone و PvP 🟢",
                "۳ DNS برتر یک‌جا و بدون ری‌استارت قفل شدند (اوج پینگ فقط ${maxSpike}ms و افت پکت ${lossPct}%). با خیال راحت وارد فایت شوید."
            )
        }

        AuditReport(
            selectedDns = chosenPreset,
            backupDns = backupPreset,
            topWorkingDns = cleanWorking.take(3),
            avgPingMs = avgPing,
            maxSpikeMs = maxSpike,
            jitterMs = jitter,
            packetLossPct = lossPct,
            dnsLatencyMs = bestDnsResult?.dnsLatencyMs ?: -1,
            readiness = readiness,
            summaryTitle = title,
            summaryDetail = detail,
            testedCount = DNS_PRESETS.size
        )
    }

    private fun resolveBestEuProbeHost(resolvedAlbionIp: String?): Pair<String, Int> {
        for ((host, port) in EU_PROBE_HOSTS) {
            if (measureTcpRtt(host, port, timeoutMs = 1200) != null) {
                return host to port
            }
        }
        if (!resolvedAlbionIp.isNullOrBlank()) {
            return resolvedAlbionIp to 443
        }
        return EU_PROBE_HOSTS.first()
    }

    private fun measureTcpRtt(host: String, port: Int, timeoutMs: Int): Int? {
        return try {
            val start = System.nanoTime()
            Socket().use { socket ->
                socket.tcpNoDelay = true
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            ((System.nanoTime() - start) / 1_000_000L).toInt().coerceAtLeast(1)
        } catch (_: Exception) {
            null
        }
    }

    private fun calculateJitter(samples: List<Int>): Int {
        if (samples.size < 2) return 0
        var diffSum = 0
        for (i in 1 until samples.size) {
            diffSum += abs(samples[i] - samples[i - 1])
        }
        return (diffSum.toDouble() / (samples.size - 1)).roundToInt()
    }

    private fun probeDnsUdp53(preset: DnsPreset): DnsProbeResult {
        var socket: DatagramSocket? = null
        return try {
            val txId = Random.nextInt(1, 65535)
            val queryBytes = buildDnsQueryPacket(txId, DNS_QUERY_DOMAIN)
            val address = InetAddress.getByName(preset.primary)

            socket = DatagramSocket()
            socket.soTimeout = 1100

            val start = System.nanoTime()
            socket.send(DatagramPacket(queryBytes, queryBytes.size, address, 53))

            val buffer = ByteArray(512)
            val responsePacket = DatagramPacket(buffer, buffer.size)
            socket.receive(responsePacket)
            val latencyMs = ((System.nanoTime() - start) / 1_000_000L).toInt().coerceAtLeast(1)

            val ip = extractFirstIpv4Answer(buffer, responsePacket.length)
            val sinkholed = ip == null || ip.startsWith("10.10.34.") || ip == "0.0.0.0" || ip == "127.0.0.1"

            DnsProbeResult(
                preset = preset,
                dnsReachable = ip != null,
                resolvedIp = ip,
                dnsLatencyMs = latencyMs,
                isSinkholed = sinkholed
            )
        } catch (_: Exception) {
            DnsProbeResult(
                preset = preset,
                dnsReachable = false,
                resolvedIp = null,
                dnsLatencyMs = 9999,
                isSinkholed = false
            )
        } finally {
            socket?.close()
        }
    }

    private fun buildDnsQueryPacket(txId: Int, domain: String): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeShort(txId)
        dos.writeShort(0x0100)
        dos.writeShort(1)
        dos.writeShort(0)
        dos.writeShort(0)
        dos.writeShort(0)

        domain.split(".").forEach { label ->
            val bytes = label.toByteArray(Charsets.US_ASCII)
            dos.writeByte(bytes.size)
            dos.write(bytes)
        }
        dos.writeByte(0)
        dos.writeShort(1)
        dos.writeShort(1)
        dos.flush()
        return baos.toByteArray()
    }

    private fun extractFirstIpv4Answer(data: ByteArray, length: Int): String? {
        if (length < 12) return null
        val anCount = ((data[6].toInt() and 0xFF) shl 8) or (data[7].toInt() and 0xFF)
        if (anCount <= 0) return null

        var pos = 12
        while (pos < length && data[pos].toInt() != 0) {
            val len = data[pos].toInt() and 0xFF
            pos += len + 1
        }
        pos += 5

        repeat(anCount) {
            if (pos + 12 > length) return null
            if ((data[pos].toInt() and 0xC0) == 0xC0) {
                pos += 2
            } else {
                while (pos < length && data[pos].toInt() != 0) {
                    pos += (data[pos].toInt() and 0xFF) + 1
                }
                pos += 1
            }
            if (pos + 10 > length) return null
            val type = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            val rdLength = ((data[pos + 8].toInt() and 0xFF) shl 8) or (data[pos + 9].toInt() and 0xFF)
            pos += 10
            if (type == 1 && rdLength == 4 && pos + 4 <= length) {
                val b1 = data[pos].toInt() and 0xFF
                val b2 = data[pos + 1].toInt() and 0xFF
                val b3 = data[pos + 2].toInt() and 0xFF
                val b4 = data[pos + 3].toInt() and 0xFF
                return "$b1.$b2.$b3.$b4"
            }
            pos += rdLength
        }
        return null
    }
}
