package com.albionguard.eu

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

data class ParsedProxyNode(
    val rawUri: String,
    val protocol: String,
    val label: String,
    val host: String,
    val port: Int,
    val outboundJson: JSONObject
)

object ProxyConfigParser {

    fun parseBatch(rawText: String): List<ParsedProxyNode> {
        val decoded = tryDecodeSubscription(rawText)
        val lines = decoded.lines()
            .map { it.trim() }
            .filter { it.startsWith("vless://", true) || it.startsWith("ss://", true) || it.startsWith("trojan://", true) }
            .distinct()

        val result = mutableListOf<ParsedProxyNode>()
        lines.forEachIndexed { idx, line ->
            val node = when {
                line.startsWith("vless://", true) -> parseVless(line, "proxy_$idx")
                line.startsWith("ss://", true) -> parseShadowsocks(line, "proxy_$idx")
                line.startsWith("trojan://", true) -> parseTrojan(line, "proxy_$idx")
                else -> null
            }
            if (node != null) result.add(node)
        }
        return result
    }

    private fun tryDecodeSubscription(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.contains("vless://") || trimmed.contains("ss://") || trimmed.contains("trojan://")) {
            return trimmed
        }
        return try {
            val bytes = Base64.decode(trimmed.replace("\n", "").replace("\r", ""), Base64.DEFAULT)
            String(bytes, Charsets.UTF_8)
        } catch (_: Exception) {
            trimmed
        }
    }

    private fun parseVless(raw: String, tag: String): ParsedProxyNode? {
        return try {
            val uri = Uri.parse(raw)
            val uuid = uri.userInfo?.trim().orEmpty()
            val host = uri.host?.trim().orEmpty()
            val port = if (uri.port > 0) uri.port else 443
            if (uuid.isBlank() || host.isBlank()) return null

            val label = decodeFragment(uri.fragment, "VLESS $host")
            val encryption = uri.getQueryParameter("encryption")?.ifBlank { "none" } ?: "none"
            val flow = uri.getQueryParameter("flow").orEmpty()

            val userObj = JSONObject().apply {
                put("id", uuid)
                put("encryption", encryption)
                if (flow.isNotBlank()) put("flow", flow)
            }
            val vnextObj = JSONObject().apply {
                put("address", host)
                put("port", port)
                put("users", JSONArray().put(userObj))
            }
            val outbound = JSONObject().apply {
                put("tag", tag)
                put("protocol", "vless")
                put("settings", JSONObject().put("vnext", JSONArray().put(vnextObj)))
                put("streamSettings", buildStreamSettings(uri, host))
            }

            ParsedProxyNode(raw, "VLESS", label, host, port, outbound)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseTrojan(raw: String, tag: String): ParsedProxyNode? {
        return try {
            val uri = Uri.parse(raw)
            val password = uri.userInfo?.trim().orEmpty()
            val host = uri.host?.trim().orEmpty()
            val port = if (uri.port > 0) uri.port else 443
            if (password.isBlank() || host.isBlank()) return null

            val label = decodeFragment(uri.fragment, "Trojan $host")
            val serverObj = JSONObject().apply {
                put("address", host)
                put("port", port)
                put("password", password)
            }
            val stream = buildStreamSettings(uri, host, defaultSecurity = "tls")
            val outbound = JSONObject().apply {
                put("tag", tag)
                put("protocol", "trojan")
                put("settings", JSONObject().put("servers", JSONArray().put(serverObj)))
                put("streamSettings", stream)
            }

            ParsedProxyNode(raw, "Trojan", label, host, port, outbound)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseShadowsocks(raw: String, tag: String): ParsedProxyNode? {
        return try {
            val withoutScheme = raw.substringAfter("://")
            val fragIdx = withoutScheme.indexOf('#')
            val fragment = if (fragIdx >= 0) withoutScheme.substring(fragIdx + 1) else ""
            val mainPart = (if (fragIdx >= 0) withoutScheme.substring(0, fragIdx) else withoutScheme)
                .substringBefore('?')

            val method: String
            val password: String
            val host: String
            val port: Int

            if (mainPart.contains('@')) {
                // SIP002: base64(method:pass)@host:port OR method:pass@host:port
                val userPart = mainPart.substringBefore('@')
                val hostPort = mainPart.substringAfter('@')
                val decodedUser = if (userPart.contains(':')) {
                    URLDecoder.decode(userPart, "UTF-8")
                } else {
                    decodeBase64Flex(userPart)
                }
                method = decodedUser.substringBefore(':')
                password = decodedUser.substringAfter(':')
                val hp = splitHostPort(hostPort) ?: return null
                host = hp.first
                port = hp.second
            } else {
                // Legacy: base64(method:pass@host:port)
                val decoded = decodeBase64Flex(mainPart)
                val userPart = decoded.substringBeforeLast('@')
                val hostPort = decoded.substringAfterLast('@')
                method = userPart.substringBefore(':')
                password = userPart.substringAfter(':')
                val hp = splitHostPort(hostPort) ?: return null
                host = hp.first
                port = hp.second
            }

            if (method.isBlank() || host.isBlank() || port <= 0) return null
            val label = decodeFragment(fragment, "SS $host")

            val serverObj = JSONObject().apply {
                put("address", host)
                put("port", port)
                put("method", method)
                put("password", password)
                put("uot", false)
            }
            val outbound = JSONObject().apply {
                put("tag", tag)
                put("protocol", "shadowsocks")
                put("settings", JSONObject().put("servers", JSONArray().put(serverObj)))
                put("streamSettings", JSONObject().put("network", "tcp"))
            }

            ParsedProxyNode(raw, "SS", label, host, port, outbound)
        } catch (_: Exception) {
            null
        }
    }

    private fun buildStreamSettings(uri: Uri, defaultHost: String, defaultSecurity: String = "none"): JSONObject {
        val rawType = (uri.getQueryParameter("type") ?: "tcp").lowercase()
        val network = when (rawType) {
            "splithttp" -> "xhttp"
            else -> rawType
        }
        val security = (uri.getQueryParameter("security") ?: defaultSecurity).lowercase()
        val sni = (uri.getQueryParameter("sni") ?: uri.getQueryParameter("host") ?: defaultHost).trim()
        val fp = (uri.getQueryParameter("fp") ?: "chrome").ifBlank { "chrome" }
        val alpnRaw = uri.getQueryParameter("alpn").orEmpty()

        val stream = JSONObject().apply {
            put("network", network)
            put("security", security)
        }

        when (security) {
            "tls" -> {
                val tls = JSONObject().apply {
                    if (sni.isNotBlank()) put("serverName", sni)
                    put("fingerprint", fp)
                    if (alpnRaw.isNotBlank()) {
                        val arr = JSONArray()
                        alpnRaw.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { arr.put(it) }
                        if (arr.length() > 0) put("alpn", arr)
                    }
                }
                stream.put("tlsSettings", tls)
            }
            "reality" -> {
                val reality = JSONObject().apply {
                    if (sni.isNotBlank()) put("serverName", sni)
                    put("fingerprint", fp)
                    put("publicKey", uri.getQueryParameter("pbk").orEmpty())
                    put("shortId", uri.getQueryParameter("sid").orEmpty())
                    val spx = uri.getQueryParameter("spx").orEmpty()
                    if (spx.isNotBlank()) put("spiderX", spx)
                }
                stream.put("realitySettings", reality)
            }
        }

        val path = uri.getQueryParameter("path").orEmpty().ifBlank { "/" }
        val hostHeader = (uri.getQueryParameter("host") ?: sni).trim()

        when (network) {
            "ws" -> {
                val ws = JSONObject().apply {
                    put("path", path)
                    if (hostHeader.isNotBlank()) {
                        put("headers", JSONObject().put("Host", hostHeader))
                    }
                }
                stream.put("wsSettings", ws)
            }
            "grpc" -> {
                val serviceName = uri.getQueryParameter("serviceName").orEmpty()
                val grpc = JSONObject().apply {
                    put("serviceName", serviceName)
                    put("multiMode", uri.getQueryParameter("mode") == "multi")
                }
                stream.put("grpcSettings", grpc)
            }
            "httpupgrade" -> {
                val hu = JSONObject().apply {
                    put("path", path)
                    if (hostHeader.isNotBlank()) put("host", hostHeader)
                }
                stream.put("httpupgradeSettings", hu)
            }
            "xhttp" -> {
                val xh = JSONObject().apply {
                    put("path", path)
                    if (hostHeader.isNotBlank()) put("host", hostHeader)
                }
                stream.put("xhttpSettings", xh)
            }
        }

        return stream
    }

    /**
     * Minimal single-outbound Xray JSON for Libv2ray.measureOutboundDelay().
     */
    fun buildSingleTestConfig(node: ParsedProxyNode): String {
        val outboundCopy = JSONObject(node.outboundJson.toString()).apply {
            put("tag", "proxy")
        }
        val root = JSONObject().apply {
            put("log", JSONObject().put("loglevel", "none"))
            put("outbounds", JSONArray().put(outboundCopy))
        }
        return root.toString()
    }

    /**
     * Builds the full Xray v26 Native TUN Gaming JSON with Top-N leastPing Auto-Failover Balancer!
     * If the #1 Germany server degrades or drops, Xray automatically shifts traffic to #2/#3
     * WITHOUT tearing down Android's tun0 VPN interface!
     */
    fun buildGamingTunConfig(topNodes: List<ParsedProxyNode>): String {
        val outbounds = JSONArray()
        val proxyTags = JSONArray()

        topNodes.forEachIndexed { idx, node ->
            val tag = "game_node_$idx"
            val copy = JSONObject(node.outboundJson.toString()).apply {
                put("tag", tag)
            }
            outbounds.put(copy)
            proxyTags.put(tag)
        }

        outbounds.put(JSONObject().apply {
            put("tag", "direct")
            put("protocol", "freedom")
            put("settings", JSONObject().put("targetStrategy", "UseIPv4"))
        })
        outbounds.put(JSONObject().apply {
            put("tag", "dns-out")
            put("protocol", "dns")
        })

        val tunInbound = JSONObject().apply {
            put("tag", "tun-in")
            put("protocol", "tun")
            put("settings", JSONObject().put("MTU", 1280))
            put("sniffing", JSONObject().apply {
                put("enabled", true)
                put("destOverride", JSONArray().put("http").put("tls").put("quic"))
            })
        }

        val rules = JSONArray().apply {
            put(JSONObject().apply {
                put("type", "field")
                put("inboundTag", JSONArray().put("tun-in"))
                put("port", "53")
                put("outboundTag", "dns-out")
            })
            if (topNodes.size > 1) {
                put(JSONObject().apply {
                    put("type", "field")
                    put("network", "tcp,udp")
                    put("balancerTag", "gaming_balancer")
                })
            } else {
                put(JSONObject().apply {
                    put("type", "field")
                    put("network", "tcp,udp")
                    put("outboundTag", "game_node_0")
                })
            }
        }

        val routing = JSONObject().apply {
            put("domainStrategy", "AsIs")
            put("rules", rules)
            if (topNodes.size > 1) {
                val balancer = JSONObject().apply {
                    put("tag", "gaming_balancer")
                    put("selector", proxyTags)
                    put("fallbackTag", "game_node_0")
                    put("strategy", JSONObject().put("type", "leastPing"))
                }
                put("balancers", JSONArray().put(balancer))
            }
        }

        val root = JSONObject().apply {
            put("log", JSONObject().put("loglevel", "warning"))
            put("dns", JSONObject().apply {
                put("queryStrategy", "UseIPv4")
                put("servers", JSONArray().put("1.1.1.1").put("8.8.8.8"))
            })
            put("inbounds", JSONArray().put(tunInbound))
            put("outbounds", outbounds)
            put("routing", routing)
            if (topNodes.size > 1) {
                put("observatory", JSONObject().apply {
                    put("subjectSelector", proxyTags)
                    put("probeURL", "https://www.gstatic.com/generate_204")
                    put("probeInterval", "25s")
                    put("enableConcurrency", true)
                })
            }
        }
        return root.toString()
    }

    private fun decodeBase64Flex(input: String): String {
        val cleaned = input.trim().replace('-', '+').replace('_', '/')
        val padded = cleaned + "=".repeat((4 - cleaned.length % 4) % 4)
        return String(Base64.decode(padded, Base64.DEFAULT), Charsets.UTF_8)
    }

    private fun splitHostPort(hostPort: String): Pair<String, Int>? {
        val idx = hostPort.lastIndexOf(':')
        if (idx <= 0) return null
        val host = hostPort.substring(0, idx).trim().removeSurrounding("[", "]")
        val port = hostPort.substring(idx + 1).trim().toIntOrNull() ?: return null
        return host to port
    }

    private fun decodeFragment(fragment: String?, fallback: String): String {
        if (fragment.isNullOrBlank()) return fallback
        return try {
            URLDecoder.decode(fragment, "UTF-8").trim().ifBlank { fallback }
        } catch (_: Exception) {
            fallback
        }
    }
}
