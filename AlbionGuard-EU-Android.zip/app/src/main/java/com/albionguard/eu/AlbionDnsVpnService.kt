package com.albionguard.eu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AlbionDnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.albionguard.eu.ACTION_START"
        const val ACTION_STOP = "com.albionguard.eu.ACTION_STOP"
        const val EXTRA_PRIMARY_DNS = "extra_primary_dns"
        const val EXTRA_SECONDARY_DNS = "extra_secondary_dns"
        const val EXTRA_DNS_NAME = "extra_dns_name"

        private const val CHANNEL_ID = "albion_guard_channel"
        private const val NOTIF_ID = 7071

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var activeDnsName: String = ""
            private set

        @Volatile
        var lastLivePingMs: Int? = null
            private set
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchdogJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopGuard()
            return START_NOT_STICKY
        }

        val primaryDns = intent?.getStringExtra(EXTRA_PRIMARY_DNS) ?: "10.202.10.10"
        val secondaryDns = intent?.getStringExtra(EXTRA_SECONDARY_DNS) ?: "10.202.10.11"
        val dnsName = intent?.getStringExtra(EXTRA_DNS_NAME) ?: "رادار گیم"

        startGuard(primaryDns, secondaryDns, dnsName)
        return START_STICKY
    }

    private fun startGuard(primaryDns: String, secondaryDns: String, dnsName: String) {
        createNotificationChannel()
        activeDnsName = dnsName
        isRunning = true

        startForeground(NOTIF_ID, buildNotification("متصل به $dnsName | در حال پایش پینگ اروپا..."))

        // Close any previous interface cleanly
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }

        // Zero-overhead DNS-only VpnService:
        // Overrides system DNS over UDP-53 WITHOUT capturing 0.0.0.0/0 game traffic,
        // so Albion Online UDP packets flow directly with zero proxy latency!
        val builder = Builder()
            .setSession("AlbionGuard EU ($dnsName)")
            .setMtu(1500)
            .addAddress("10.120.0.2", 32)
            .addDnsServer(primaryDns)
            .addDnsServer(secondaryDns)
            .setBlocking(false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        vpnInterface = builder.establish()
        if (vpnInterface == null) {
            stopGuard()
            return
        }

        acquireLocks()
        startLiveWatchdog(dnsName)
    }

    private fun acquireLocks() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(lockMode, "AlbionGuard::LowLatencyWifi").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (_: Exception) {
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlbionGuard::KeepAlive").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(4 * 60 * 60 * 1000L) // up to 4h gaming session
            }
        } catch (_: Exception) {
        }
    }

    private fun startLiveWatchdog(dnsName: String) {
        watchdogJob?.cancel()
        watchdogJob = serviceScope.launch {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            while (isActive && isRunning) {
                val ping = AlbionAuditEngine.probeQuickEuPing()
                lastLivePingMs = ping
                val statusText = if (ping != null) {
                    "فعال ($dnsName) • پینگ اروپا: ${ping}ms 🟢"
                } else {
                    "فعال ($dnsName) • هشدار افت اتصال 🟡"
                }
                nm.notify(NOTIF_ID, buildNotification(statusText))
                delay(10_000L)
            }
        }
    }

    private fun stopGuard() {
        isRunning = false
        lastLivePingMs = null
        watchdogJob?.cancel()
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (_: Exception) {
        }
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopGuard()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopGuard()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "سرویس پایدارساز آلبیون اروپا",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نمایش زنده وضعیت DNS و پینگ سرور اروپا"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AlbionDnsVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("AlbionGuard EU")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopIntent)
            .build()
    }
}
