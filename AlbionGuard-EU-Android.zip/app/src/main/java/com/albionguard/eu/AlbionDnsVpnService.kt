package com.albionguard.eu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.nio.ByteBuffer

class AlbionDnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.albionguard.eu.ACTION_START"
        const val ACTION_STOP = "com.albionguard.eu.ACTION_STOP"
        const val EXTRA_DNS_IPS = "extra_dns_ips"
        const val EXTRA_DNS_NAMES = "extra_dns_names"

        private const val CHANNEL_ID = "albion_guard_channel"
        private const val NOTIF_ID = 7071

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var activeDnsName: String = ""
            private set

        @Volatile
        var activeDnsPairIps: String = ""
            private set
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var drainThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopGuard()
            return START_NOT_STICKY
        }

        val ips = intent?.getStringArrayListExtra(EXTRA_DNS_IPS)
            ?.filter { it.isNotBlank() }
            ?.distinct()
            ?.take(3)
            ?: listOf("178.22.122.100", "185.55.226.26", "1.1.1.1")

        val names = intent?.getStringArrayListExtra(EXTRA_DNS_NAMES)
            ?.filter { it.isNotBlank() }
            ?.map { it.substringBefore(" (") }
            ?.distinct()
            ?.take(3)
            ?: listOf("شکن", "بگذر", "کلودفلر")

        startGuard(ips, names)
        return START_STICKY
    }

    private fun startGuard(dnsIps: List<String>, dnsNames: List<String>) {
        createNotificationChannel()

        val label = dnsNames.take(2).joinToString(" + ")
        activeDnsName = label
        activeDnsPairIps = dnsIps.take(2).joinToString("  /  ")
        isRunning = true

        startForeground(
            NOTIF_ID,
            buildNotification("پایدار و قفل‌شده ($label) • بدون قطعی 🟢")
        )

        // Close any previous interface cleanly ONLY on explicit user Start/Switch
        closeInterfaceOnly()

        // Black-Zone Safe VpnService configuration:
        // 1) Registers ALL top 3 verified DNS servers directly in Android netd (zero-restart failover)
        // 2) Zero 0.0.0.0/0 route -> 100% of Albion Online UDP 5055/5056/5058 traffic flows directly
        // 3) allowBypass() + setUnderlyingNetworks(null) -> prevents Samsung/Android 14-15 socket resets
        // 4) MTU 1280 -> zero UDP fragmentation on LTE/TD-LTE
        // 5) ZERO 10-second background watchdog or automatic tun0 rebuilds mid-fight!
        val builder = Builder()
            .setSession("Albion Guard ($label)")
            .setMtu(1280)
            .addAddress("10.120.0.2", 32)
            .allowBypass()
            .setBlocking(true)

        dnsIps.forEach { ip ->
            try {
                builder.addDnsServer(ip)
            } catch (_: Exception) {
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            builder.setUnderlyingNetworks(null)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        vpnInterface = builder.establish()
        if (vpnInterface == null) {
            stopGuard()
            return
        }

        acquireLocks()
        startPassiveTunDrain(vpnInterface!!)
    }

    /**
     * Passively drains any stray OS packets that hit tun0 so the kernel ring buffer
     * never stalls on Samsung Exynos / One UI kernels. Uses virtually 0% CPU.
     */
    private fun startPassiveTunDrain(pfd: ParcelFileDescriptor) {
        drainThread?.interrupt()
        drainThread = Thread({
            try {
                val input = FileInputStream(pfd.fileDescriptor)
                val buf = ByteBuffer.allocate(2048).array()
                while (isRunning && !Thread.currentThread().isInterrupted) {
                    val read = input.read(buf)
                    if (read < 0) break
                }
            } catch (_: Exception) {
            }
        }, "AlbionGuard-TunDrain").apply {
            isDaemon = true
            start()
        }
    }

    private fun acquireLocks() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(lockMode, "AlbionGuard::LowLatencyWifi").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (_: Exception) {
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlbionGuard::KeepAlive").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(6 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun closeInterfaceOnly() {
        drainThread?.interrupt()
        drainThread = null
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (_: Exception) {
        }
    }

    private fun stopGuard() {
        isRunning = false
        closeInterfaceOnly()
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopGuard()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopGuard()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "سرویس پایدارساز آلبیون اروپا",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نگهداری پایدار DNS ترکیبی برای آلبیون آنلاین"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AlbionDnsVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("Albion Guard")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopIntent)
            .build()
    }
}
