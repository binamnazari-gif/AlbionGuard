package com.albionguard.eu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AlbionDnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.albionguard.eu.ACTION_START"
        const val ACTION_STOP = "com.albionguard.eu.ACTION_STOP"
        const val EXTRA_DNS_IPS = "extra_dns_ips"
        const val EXTRA_DNS_NAMES = "extra_dns_names"

        private const val CHANNEL_ID = "albion_guard_channel"
        private const val NOTIF_ID = 7071

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var activeDnsName: String = ""
            private set

        @Volatile
        var activeDnsPairIps: String = ""
            private set

        @Volatile
        var lastLivePingMs: Int? = null
            private set
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchdogJob: Job? = null

    private var dnsPoolIps: List<String> = emptyList()
    private var dnsPoolNames: List<String> = emptyList()
    private var currentIndex = 0
    private var lastRotationTimeMs = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopGuard()
            return START_NOT_STICKY
        }

        val ips = intent?.getStringArrayListExtra(EXTRA_DNS_IPS)?.filter { it.isNotBlank() }
            ?: listOf("10.202.10.10", "178.22.122.100", "1.1.1.1")
        val names = intent?.getStringArrayListExtra(EXTRA_DNS_NAMES)?.filter { it.isNotBlank() }
            ?: listOf("رادار گیم", "شکن", "کلودفلر")

        dnsPoolIps = ips
        dnsPoolNames = names
        currentIndex = 0
        lastRotationTimeMs = System.currentTimeMillis()

        startGuard()
        return START_STICKY
    }

    private fun startGuard() {
        createNotificationChannel()
        isRunning = true

        val (pIp, sIp, label) = getCurrentHybridPair()
        activeDnsName = label
        activeDnsPairIps = "$pIp  /  $sIp"

        startForeground(NOTIF_ID, buildNotification("ترکیبی فعال: $label | در حال پایش..."))

        if (!establishHybridDnsInterface(pIp, sIp, label)) {
            stopGuard()
            return
        }

        acquireLocks()
        startLiveWatchdog()
    }

    /**
     * Hybrid Dual-Provider Pair:
     * Uses provider #i as Primary and provider #(i+1) as Secondary simultaneously,
     * so if Primary even blinks for a millisecond, Android instantly resolves via Secondary
     * with ZERO tunnel restart or gameplay hiccup.
     */
    private fun getCurrentHybridPair(): Triple<String, String, String> {
        val size = dnsPoolIps.size.coerceAtLeast(1)
        val i1 = currentIndex % size
        val i2 = (currentIndex + 1) % size
        val pIp = dnsPoolIps.getOrElse(i1) { "10.202.10.10" }
        val sIp = dnsPoolIps.getOrElse(i2) { "1.1.1.1" }
        val n1 = dnsPoolNames.getOrElse(i1) { pIp }.substringBefore(" (")
        val n2 = dnsPoolNames.getOrElse(i2) { sIp }.substringBefore(" (")
        val label = if (i1 != i2 && n1 != n2) "$n1 + $n2" else n1
        return Triple(pIp, sIp, label)
    }

    private fun establishHybridDnsInterface(primaryDns: String, secondaryDns: String, label: String): Boolean {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }

        val builder = Builder()
            .setSession("Albion Guard ($label)")
            .setMtu(1400)
            .addAddress("10.120.0.2", 32)
            .addDnsServer(primaryDns)
            .setBlocking(false)

        if (secondaryDns.isNotBlank() && secondaryDns != primaryDns) {
            builder.addDnsServer(secondaryDns)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        vpnInterface = builder.establish()
        return vpnInterface != null
    }

    private fun acquireLocks() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(lockMode, "AlbionGuard::LowLatencyWifi").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (_: Exception) {
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlbionGuard::KeepAlive").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(4 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun startLiveWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = serviceScope.launch {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            var consecutiveDrops = 0

            while (isActive && isRunning) {
                val ping = AlbionAuditEngine.probeQuickEuPing()
                lastLivePingMs = ping

                if (ping == null || ping > 450) {
                    consecutiveDrops++
                    val now = System.currentTimeMillis()
                    val cooldownPassed = (now - lastRotationTimeMs) >= 60_000L

                    if (consecutiveDrops >= 3 && cooldownPassed && dnsPoolIps.size > 1) {
                        consecutiveDrops = 0
                        lastRotationTimeMs = now
                        currentIndex = (currentIndex + 1) % dnsPoolIps.size
                        val (pIp, sIp, label) = getCurrentHybridPair()
                        if (establishHybridDnsInterface(pIp, sIp, label)) {
                            activeDnsName = label
                            activeDnsPairIps = "$pIp  /  $sIp"
                            nm.notify(NOTIF_ID, buildNotification("تعویض خودکار به $label انجام شد 🟡"))
                        }
                    } else {
                        val msg = if (ping != null) {
                            "$activeDnsName • هشدار پینگ بالا: ${ping}ms 🟡"
                        } else {
                            "$activeDnsName • هشدار افت اتصال 🟡"
                        }
                        nm.notify(NOTIF_ID, buildNotification(msg))
                    }
                } else {
                    consecutiveDrops = 0
                    nm.notify(NOTIF_ID, buildNotification("$activeDnsName • پینگ اروپا: ${ping}ms 🟢"))
                }
                delay(10_000L)
            }
        }
    }

    private fun stopGuard() {
        isRunning = false
        lastLivePingMs = null
        watchdogJob?.cancel()
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (_: Exception) {
        }
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopGuard()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopGuard()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "سرویس پایدارساز آلبیون اروپا",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نمایش زنده وضعیت DNS ترکیبی و پینگ سرور اروپا"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AlbionDnsVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("Albion Guard")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopIntent)
            .build()
    }
}
