package com.albionguard.eu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AlbionDnsVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.albionguard.eu.ACTION_START"
        const val ACTION_STOP = "com.albionguard.eu.ACTION_STOP"
        const val EXTRA_PRIMARY_DNS = "extra_primary_dns"
        const val EXTRA_SECONDARY_DNS = "extra_secondary_dns"
        const val EXTRA_DNS_NAME = "extra_dns_name"
        const val EXTRA_BACKUP_PRIMARY = "extra_backup_primary"
        const val EXTRA_BACKUP_SECONDARY = "extra_backup_secondary"
        const val EXTRA_BACKUP_NAME = "extra_backup_name"

        private const val CHANNEL_ID = "albion_guard_channel"
        private const val NOTIF_ID = 7071

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var activeDnsName: String = ""
            private set

        @Volatile
        var lastLivePingMs: Int? = null
            private set
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var watchdogJob: Job? = null

    private var backupPrimary: String? = null
    private var backupSecondary: String? = null
    private var backupName: String? = null
    private var failoverTriggered = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopGuard()
            return START_NOT_STICKY
        }

        val primaryDns = intent?.getStringExtra(EXTRA_PRIMARY_DNS) ?: "10.202.10.10"
        val secondaryDns = intent?.getStringExtra(EXTRA_SECONDARY_DNS) ?: "10.202.10.11"
        val dnsName = intent?.getStringExtra(EXTRA_DNS_NAME) ?: "رادار گیم"

        backupPrimary = intent?.getStringExtra(EXTRA_BACKUP_PRIMARY)
        backupSecondary = intent?.getStringExtra(EXTRA_BACKUP_SECONDARY)
        backupName = intent?.getStringExtra(EXTRA_BACKUP_NAME)
        failoverTriggered = false

        startGuard(primaryDns, secondaryDns, dnsName)
        return START_STICKY
    }

    private fun startGuard(primaryDns: String, secondaryDns: String, dnsName: String) {
        createNotificationChannel()
        activeDnsName = dnsName
        isRunning = true

        startForeground(NOTIF_ID, buildNotification("متصل به $dnsName | در حال پایش پینگ اروپا..."))

        if (!establishDnsInterface(primaryDns, secondaryDns, dnsName)) {
            stopGuard()
            return
        }

        acquireLocks()
        startLiveWatchdog()
    }

    private fun establishDnsInterface(primaryDns: String, secondaryDns: String, dnsName: String): Boolean {
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }

        val builder = Builder()
            .setSession("AlbionGuard EU ($dnsName)")
            .setMtu(1500)
            .addAddress("10.120.0.2", 32)
            .addDnsServer(primaryDns)
            .addDnsServer(secondaryDns)
            .setBlocking(false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        vpnInterface = builder.establish()
        return vpnInterface != null
    }

    private fun acquireLocks() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(lockMode, "AlbionGuard::LowLatencyWifi").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) {
                wifiLock?.acquire()
            }
        } catch (_: Exception) {
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlbionGuard::KeepAlive").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(4 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun startLiveWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = serviceScope.launch {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            var consecutiveDrops = 0

            while (isActive && isRunning) {
                val ping = AlbionAuditEngine.probeQuickEuPing()
                lastLivePingMs = ping

                if (ping == null || ping > 450) {
                    consecutiveDrops++
                    if (consecutiveDrops >= 3 && !failoverTriggered && !backupPrimary.isNullOrBlank()) {
                        failoverTriggered = true
                        consecutiveDrops = 0
                        val bPrim = backupPrimary!!
                        val bSec = backupSecondary ?: bPrim
                        val bName = backupName ?: "DNS پشتیبان"
                        if (establishDnsInterface(bPrim, bSec, bName)) {
                            activeDnsName = "$bName (پشتیبان)"
                            nm.notify(NOTIF_ID, buildNotification("تعویض خودکار به $bName انجام شد 🟡"))
                        }
                    } else {
                        val msg = if (ping != null) {
                            "فعال ($activeDnsName) • هشدار پینگ بالا: ${ping}ms 🟡"
                        } else {
                            "فعال ($activeDnsName) • هشدار افت اتصال 🟡"
                        }
                        nm.notify(NOTIF_ID, buildNotification(msg))
                    }
                } else {
                    consecutiveDrops = 0
                    nm.notify(NOTIF_ID, buildNotification("فعال ($activeDnsName) • پینگ اروپا: ${ping}ms 🟢"))
                }
                delay(10_000L)
            }
        }
    }

    private fun stopGuard() {
        isRunning = false
        lastLivePingMs = null
        watchdogJob?.cancel()
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (_: Exception) {
        }
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopGuard()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopGuard()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "سرویس پایدارساز آلبیون اروپا",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نمایش زنده وضعیت DNS و پینگ سرور اروپا"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, AlbionDnsVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("AlbionGuard EU")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopIntent)
            .build()
    }
}
