package com.albionguard.eu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.net.wifi.WifiManager
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

enum class XrayTunnelStatus {
    IDLE,
    CONNECTING,
    RUNNING,
    ERROR
}

data class XrayVpnState(
    val status: XrayTunnelStatus = XrayTunnelStatus.IDLE,
    val activeLabel: String = "",
    val activePingMs: Int = 0,
    val poolCount: Int = 0,
    val errorMessage: String = "",
    val eventId: Long = System.nanoTime()
)

class AlbionXrayVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.albionguard.eu.XRAY_START"
        const val ACTION_STOP = "com.albionguard.eu.XRAY_STOP"
        const val EXTRA_CONFIG_JSON = "extra_config_json"
        const val EXTRA_FALLBACK_CONFIG_JSON = "extra_fallback_config_json"
        const val EXTRA_ACTIVE_LABEL = "extra_active_label"
        const val EXTRA_ACTIVE_PING_MS = "extra_active_ping_ms"
        const val EXTRA_POOL_COUNT = "extra_pool_count"

        private const val CHANNEL_ID = "albion_xray_gaming_channel"
        private const val NOTIF_ID = 7075

        private val _state = MutableStateFlow(XrayVpnState())
        val state: StateFlow<XrayVpnState> = _state.asStateFlow()

        val isRunning: Boolean
            get() = _state.value.status == XrayTunnelStatus.RUNNING ||
                _state.value.status == XrayTunnelStatus.CONNECTING

        val activeLabel: String
            get() = _state.value.activeLabel
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnInterface: ParcelFileDescriptor? = null
    private var coreController: CoreController? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopXrayTunnel(clearError = true)
            return START_NOT_STICKY
        }

        val configJson = intent?.getStringExtra(EXTRA_CONFIG_JSON).orEmpty()
        val fallbackJson = intent?.getStringExtra(EXTRA_FALLBACK_CONFIG_JSON).orEmpty()
        val label = intent?.getStringExtra(EXTRA_ACTIVE_LABEL) ?: "تونل گیمینگ"
        val pingMs = intent?.getIntExtra(EXTRA_ACTIVE_PING_MS, 0) ?: 0
        val poolCount = intent?.getIntExtra(EXTRA_POOL_COUNT, 1) ?: 1

        if (configJson.isBlank()) {
            stopXrayTunnel(clearError = true)
            return START_NOT_STICKY
        }

        startXrayTunnel(configJson, fallbackJson, label, pingMs, poolCount)
        return START_STICKY
    }

    private fun startXrayTunnel(
        configJson: String,
        fallbackJson: String,
        label: String,
        pingMs: Int,
        poolCount: Int
    ) {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("در حال اتصال تونل گیمینگ ($label)..."))
        _state.value = XrayVpnState(
            status = XrayTunnelStatus.CONNECTING,
            activeLabel = label,
            activePingMs = pingMs,
            poolCount = poolCount
        )

        serviceScope.launch {
            try {
                stopCoreOnly()
                Libv2ray.initCoreEnv(filesDir.absolutePath, "")

                val builder = Builder()
                    .setSession("Albion Guard ($label)")
                    .setMtu(1280)
                    .addAddress("10.120.0.2", 30)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                    .setBlocking(false)

                // Per-App Split Tunneling: route ONLY Albion Online through Xray
                // Albion Guard itself stays outside tun0 so Xray outbound sockets never loop!
                if (isPackageInstalled(NetworkProfiler.ALBION_PACKAGE)) {
                    builder.addAllowedApplication(NetworkProfiler.ALBION_PACKAGE)
                } else {
                    builder.addDisallowedApplication(packageName)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.setMetered(false)
                }

                val pfd = builder.establish()
                if (pfd == null) {
                    failAndStop("اجازه ساخت رابط VPN (کلید بالای صفحه) توسط اندروید صادر نشد؛ دوباره Start را بزنید.")
                    return@launch
                }
                vpnInterface = pfd

                val callback = object : CoreCallbackHandler {
                    override fun startup(): Long = 0L
                    override fun shutdown(): Long = 0L
                    override fun onEmitStatus(p0: Long, p1: String?): Long = 0L
                }

                var startedWithCount = poolCount
                var startError: Throwable? = null

                try {
                    val controller = Libv2ray.newCoreController(callback)
                    coreController = controller
                    controller.startLoop(configJson, pfd.fd)
                    if (!controller.isRunning) {
                        throw IllegalStateException("Xray core did not enter running state")
                    }
                } catch (primaryErr: Throwable) {
                    startError = primaryErr
                    try {
                        coreController?.stopLoop()
                    } catch (_: Throwable) {
                    }
                    coreController = null

                    // Automatic fallback to ultra-clean single-node TUN config
                    if (fallbackJson.isNotBlank()) {
                        try {
                            val fbController = Libv2ray.newCoreController(callback)
                            coreController = fbController
                            fbController.startLoop(fallbackJson, pfd.fd)
                            if (fbController.isRunning) {
                                startError = null
                                startedWithCount = 1
                            } else {
                                startError = IllegalStateException("Fallback single-node Xray did not start")
                            }
                        } catch (fbErr: Throwable) {
                            startError = fbErr
                        }
                    }
                }

                if (startError != null) {
                    val detail = startError.localizedMessage ?: startError.javaClass.simpleName
                    failAndStop("خطای هسته Xray: $detail")
                    return@launch
                }

                acquireLocks()
                _state.value = XrayVpnState(
                    status = XrayTunnelStatus.RUNNING,
                    activeLabel = label,
                    activePingMs = pingMs,
                    poolCount = startedWithCount,
                    errorMessage = ""
                )
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(
                    NOTIF_ID,
                    buildNotification("متصل • فقط آلبیون داخل تونل ($label • $startedWithCount سرور) 🟢")
                )
            } catch (t: Throwable) {
                failAndStop("خطای هسته Xray: ${t.localizedMessage ?: t.javaClass.simpleName}")
            }
        }
    }

    private fun failAndStop(reason: String) {
        stopCoreOnly()
        releaseLocks()
        _state.value = XrayVpnState(
            status = XrayTunnelStatus.ERROR,
            activeLabel = "",
            activePingMs = 0,
            poolCount = 0,
            errorMessage = reason
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun stopCoreOnly() {
        try {
            coreController?.stopLoop()
        } catch (_: Throwable) {
        } finally {
            coreController = null
        }
        try {
            vpnInterface?.close()
        } catch (_: Throwable) {
        } finally {
            vpnInterface = null
        }
    }

    private fun stopXrayTunnel(clearError: Boolean) {
        stopCoreOnly()
        releaseLocks()
        if (clearError) {
            _state.value = XrayVpnState(status = XrayTunnelStatus.IDLE)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireLocks() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            if (wifiLock == null) {
                wifiLock = wm.createWifiLock(lockMode, "AlbionGuard::XrayWifiLock").apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
        } catch (_: Exception) {
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlbionGuard::XrayWakeLock").apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld == false) wakeLock?.acquire(6 * 60 * 60 * 1000L)
        } catch (_: Exception) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
    }

    private fun isPackageInstalled(pkgName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(pkgName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(pkgName, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onRevoke() {
        stopXrayTunnel(clearError = true)
        super.onRevoke()
    }

    override fun onDestroy() {
        stopXrayTunnel(clearError = false)
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تونل گیمینگ آلبیون (Xray)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "تونل اختصاصی و ضدریکانکت فقط برای آلبیون آنلاین"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            30,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            31,
            Intent(this, AlbionXrayVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_shield)
            .setContentTitle("Albion Guard • تونل گیمینگ")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "توقف", stopIntent)
            .build()
    }
}
