package com.albionguard.eu

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.albionguard.eu.databinding.ActivityMainBinding
import com.google.android.material.chip.Chip
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingPool: List<DnsPreset> = emptyList()
    private var lastReport: AuditReport? = null
    private var isAuditingDns = false
    private var isScanningConfigs = false
    private var configScanJob: Job? = null

    private var currentPoolSnapshot: OrganizedPoolSnapshot? = null
    private var selectedCountryCode: String = ""
    private var selectedGroupIndex: Int = 1

    private var pendingXrayJson: String? = null
    private var pendingXrayFallbackJson: String? = null
    private var pendingXrayLabel: String = ""
    private var pendingXrayPingMs: Int = 0
    private var pendingXrayCount: Int = 0
    private var userManuallyPickedMode = false
    private var networkCallbackRegistered = false

    private val connectivityManager by lazy {
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    private val liveNetworkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { refreshDeviceProfile() }
        }

        override fun onLost(network: Network) {
            runOnUiThread { refreshDeviceProfile() }
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val xrayJson = pendingXrayJson
            if (!xrayJson.isNullOrBlank()) {
                val fbJson = pendingXrayFallbackJson.orEmpty()
                pendingXrayJson = null
                pendingXrayFallbackJson = null
                startXrayServiceNow(xrayJson, fbJson, pendingXrayLabel, pendingXrayPingMs, pendingXrayCount)
            } else if (pendingPool.isNotEmpty()) {
                startVpnWithPool(pendingPool)
            }
        } else {
            pendingXrayJson = null
            pendingXrayFallbackJson = null
            Toast.makeText(this, "برای اتصال به تونل/DNS، اجازه VPN لازم است.", Toast.LENGTH_LONG).show()
            resetIdleUi()
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* optional */ }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startInlineVoiceRoom()
        } else {
            Toast.makeText(this, "برای ورود به ویس گیلد، اجازه میکروفون لازم است.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvVersionBadge.text = "v${BuildConfig.VERSION_NAME}"
        val prefs = getSharedPreferences("albion_guard_prefs", Context.MODE_PRIVATE)
        binding.etVoiceRoom.setText(prefs.getString("voice_room", "albion-iran") ?: "albion-iran")
        binding.etVoiceNickname.setText(prefs.getString("voice_nickname", "") ?: "")

        selectedCountryCode = GuildConfigStore.getSelectedCountry(this)
        selectedGroupIndex = GuildConfigStore.getSelectedGroupIndex(this)

        requestNotifPermissionIfNeeded()
        setupClickListeners()
        observeVoiceState()
        observeXrayState()
        refreshDeviceProfile()
        updateModePanelsVisibility()
        loadCachedPoolAndAutoPrecheck()
        syncRunningState()
        checkUpdatesSilently()
    }

    override fun onStart() {
        super.onStart()
        registerLiveNetworkMonitor()
    }

    override fun onStop() {
        super.onStop()
        unregisterLiveNetworkMonitor()
    }

    override fun onResume() {
        super.onResume()
        refreshDeviceProfile()
        syncRunningState()
    }

    private fun updateModePanelsVisibility() {
        val isTunnelMode = binding.chipModeWarp.isChecked
        binding.layoutXrayPoolPanel.visibility = if (isTunnelMode) View.VISIBLE else View.GONE
        binding.layoutConfigActions.visibility = if (isTunnelMode) View.VISIBLE else View.GONE
    }

    private fun loadCachedPoolAndAutoPrecheck() {
        val cached = GuildConfigStore.loadCachedPool(this)
        if (cached != null && cached.totalActive > 0) {
            currentPoolSnapshot = cached
            renderCountryAndGroupChips(cached)
            // Silently refresh in background only if cache is older than 10 minutes
            val ageMs = System.currentTimeMillis() - cached.updatedAtMs
            if (ageMs > 10 * 60 * 1000L && !AlbionXrayVpnService.isRunning) {
                runBackgroundConfigScan(autoConnectAfter = false, silent = true)
            }
        } else {
            // Auto-check configs on app open so START connects instantly!
            runBackgroundConfigScan(autoConnectAfter = false, silent = false)
        }
    }

    private fun runBackgroundConfigScan(
        autoConnectAfter: Boolean,
        silent: Boolean,
        onlyCountryCode: String? = null
    ) {
        if (isScanningConfigs) return
        configScanJob?.cancel()
        isScanningConfigs = true
        binding.btnRescanConfigs.isEnabled = false
        binding.btnRescanConfigs.text = "..."
        if (!silent) {
            binding.progressAudit.visibility = View.VISIBLE
            binding.progressAudit.progress = 8
            binding.tvPoolSummary.text = "در حال بررسی و جداسازی کشوری کانفیگ‌ها..."
        }

        configScanJob = lifecycleScope.launch {
            val snapshot = GuildConfigStore.scanAndOrganizeByCountry(
                context = this@MainActivity,
                onlyCountryCode = onlyCountryCode
            ) { step, pct ->
                runOnUiThread {
                    if (!silent) {
                        binding.progressAudit.progress = pct
                        binding.tvPoolSummary.text = step
                        if (autoConnectAfter) {
                            binding.tvStatusHeadline.text = step
                        }
                    }
                }
            }

            isScanningConfigs = false
            binding.btnRescanConfigs.isEnabled = true
            binding.btnRescanConfigs.text = "تست مجدد"
            binding.progressAudit.visibility = View.GONE

            currentPoolSnapshot = snapshot
            renderCountryAndGroupChips(snapshot)

            if (autoConnectAfter) {
                val grp = getSelectedGroup5()
                if (grp != null && grp.nodes.isNotEmpty()) {
                    connectSelectedGroupInstantly(grp)
                } else {
                    resetIdleUi()
                    binding.cardVerdict.visibility = View.VISIBLE
                    binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2A111A"))
                    binding.tvVerdictTitle.setTextColor(Color.parseColor("#FB7185"))
                    binding.tvVerdictTitle.text = "کانفیگ سالمی پیدا نشد 🔴"
                    binding.tvVerdictDetail.text = snapshot.statusMessage
                }
            }
        }
    }

    private fun renderCountryAndGroupChips(snapshot: OrganizedPoolSnapshot) {
        binding.chipGroupCountries.removeAllViews()
        binding.chipGroupPack5.removeAllViews()

        if (snapshot.countries.isEmpty()) {
            binding.tvPoolSummary.text = snapshot.statusMessage
            return
        }

        // Ensure valid selected country
        var activeBucket = snapshot.countries.firstOrNull { it.countryCode == selectedCountryCode }
        if (activeBucket == null) {
            activeBucket = snapshot.countries.first()
            selectedCountryCode = activeBucket.countryCode
            selectedGroupIndex = 1
            GuildConfigStore.saveSelection(this, selectedCountryCode, selectedGroupIndex)
        }

        binding.tvPoolSummary.text =
            "${snapshot.totalActive} سرور فعال در ${snapshot.countries.size} کشور (آماده اتصال فوری 🟢)"

        snapshot.countries.forEach { bucket ->
            val chip = Chip(this).apply {
                text = "${bucket.flag} ${bucket.persianName} (${bucket.totalActive})"
                isCheckable = true
                isChecked = bucket.countryCode == selectedCountryCode
                textSize = 11f
                setTextColor(Color.parseColor("#F8FAFC"))
                setOnClickListener {
                    selectedCountryCode = bucket.countryCode
                    selectedGroupIndex = 1
                    GuildConfigStore.saveSelection(this@MainActivity, selectedCountryCode, selectedGroupIndex)
                    renderPack5Chips(bucket)
                }
            }
            binding.chipGroupCountries.addView(chip)
        }

        renderPack5Chips(activeBucket)
    }

    private fun renderPack5Chips(bucket: CountryBucket) {
        binding.chipGroupPack5.removeAllViews()
        if (bucket.groups.isEmpty()) return

        if (bucket.groups.none { it.groupIndex == selectedGroupIndex }) {
            selectedGroupIndex = bucket.groups.first().groupIndex
            GuildConfigStore.saveSelection(this, bucket.countryCode, selectedGroupIndex)
        }

        bucket.groups.forEach { grp ->
            val chip = Chip(this).apply {
                text = "گروه ${grp.groupIndex} (${grp.size} سرور • ${grp.bestPingMs}ms)"
                isCheckable = true
                isChecked = grp.groupIndex == selectedGroupIndex
                textSize = 11f
                setTextColor(Color.parseColor("#38BDF8"))
                setOnClickListener {
                    selectedGroupIndex = grp.groupIndex
                    GuildConfigStore.saveSelection(this@MainActivity, bucket.countryCode, selectedGroupIndex)
                    if (!AlbionXrayVpnService.isRunning && binding.chipModeWarp.isChecked) {
                        binding.tvPingValue.text = "${grp.bestPingMs} ms"
                        binding.tvJitterValue.text = "${grp.size} سرور"
                        binding.tvStatusHeadline.text =
                            "${bucket.flag} ${bucket.persianName} • گروه ${grp.groupIndex} آماده اتصال فوری"
                    }
                }
            }
            binding.chipGroupPack5.addView(chip)
        }

        val currentGrp = bucket.groups.firstOrNull { it.groupIndex == selectedGroupIndex } ?: bucket.groups.first()
        if (!AlbionXrayVpnService.isRunning && binding.chipModeWarp.isChecked) {
            binding.tvPingValue.text = "${currentGrp.bestPingMs} ms"
            binding.tvJitterValue.text = "${currentGrp.size} سرور"
            binding.tvActiveDnsValue.text = "${bucket.flag} ${currentGrp.nodes.first().node.label}"
            binding.tvStatusHeadline.text =
                "${bucket.flag} ${bucket.persianName} • گروه ${currentGrp.groupIndex} (${currentGrp.size} سرور) آماده اتصال فوری"
        }
    }

    private fun getSelectedGroup5(): ConfigGroup5? {
        val snap = currentPoolSnapshot ?: return null
        val bucket = snap.countries.firstOrNull { it.countryCode == selectedCountryCode }
            ?: snap.countries.firstOrNull()
            ?: return null
        return bucket.groups.firstOrNull { it.groupIndex == selectedGroupIndex }
            ?: bucket.groups.firstOrNull()
    }

    private fun connectSelectedGroupInstantly(group: ConfigGroup5) {
        if (AlbionDnsVpnService.isRunning) {
            startService(Intent(this, AlbionDnsVpnService::class.java).apply {
                action = AlbionDnsVpnService.ACTION_STOP
            })
        }

        val nodes = group.nodes.map { it.node }
        val best = group.nodes.first()
        val (flag, countryName) = GuildConfigStore.countryMeta(group.countryCode)
        val displayLabel = "$flag $countryName • گروه ${group.groupIndex}"

        val configJson = ProxyConfigParser.buildGamingTunConfig(nodes)
        val fallbackJson = ProxyConfigParser.buildSingleTunFallbackConfig(best.node)

        binding.tvPingValue.text = "${best.delayMs} ms"
        binding.tvJitterValue.text = "${nodes.size} سرور"
        binding.tvLossValue.text = "0%"
        binding.tvActiveDnsValue.text = "$flag ${best.node.protocol} • ${best.node.label}"
        binding.cardQuickSwitch.visibility = View.GONE

        val prepIntent = VpnService.prepare(this)
        if (prepIntent != null) {
            pendingXrayJson = configJson
            pendingXrayFallbackJson = fallbackJson
            pendingXrayLabel = displayLabel
            pendingXrayPingMs = best.delayMs
            pendingXrayCount = nodes.size
            vpnPermissionLauncher.launch(prepIntent)
        } else {
            startXrayServiceNow(configJson, fallbackJson, displayLabel, best.delayMs, nodes.size)
        }
    }

    private fun observeVoiceState() {
        lifecycleScope.launch {
            LiveKitVoiceService.state.collect { st ->
                renderVoiceState(st)
            }
        }
    }

    private fun renderVoiceState(st: VoiceUiState) {
        when (st.status) {
            VoiceConnStatus.IDLE -> {
                binding.tvVoiceStatus.text = "خاموش"
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#64748B"))
                binding.btnVoiceJoin.isEnabled = true
                binding.btnVoiceJoin.text = "ورود به ویس"
                binding.btnVoiceJoin.setBackgroundColor(Color.parseColor("#0284C7"))
                binding.layoutVoiceControls.visibility = View.GONE
                binding.layoutVoiceMembers.visibility = View.GONE
                binding.tvVoiceError.visibility = View.GONE
                binding.etVoiceRoom.isEnabled = true
                binding.etVoiceNickname.isEnabled = true
            }
            VoiceConnStatus.CONNECTING -> {
                binding.tvVoiceStatus.text = "در حال اتصال..."
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#F59E0B"))
                binding.btnVoiceJoin.isEnabled = false
                binding.btnVoiceJoin.text = "در حال اتصال به اتاق..."
                binding.layoutVoiceControls.visibility = View.GONE
                binding.layoutVoiceMembers.visibility = View.GONE
                binding.tvVoiceError.visibility = View.GONE
                binding.etVoiceRoom.isEnabled = false
                binding.etVoiceNickname.isEnabled = false
            }
            VoiceConnStatus.CONNECTED -> {
                val count = st.members.size.coerceAtLeast(1)
                binding.tvVoiceStatus.text = "متصل ($count نفر) 🟢"
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#10B981"))
                binding.btnVoiceJoin.isEnabled = true
                binding.btnVoiceJoin.text = "خروج از ویس"
                binding.btnVoiceJoin.setBackgroundColor(Color.parseColor("#E11D48"))
                binding.layoutVoiceControls.visibility = View.VISIBLE
                binding.tvVoiceError.visibility = View.GONE
                binding.etVoiceRoom.isEnabled = false
                binding.etVoiceNickname.isEnabled = false

                if (st.isMicMuted) {
                    binding.btnMicMute.text = "میوت من: فعال 🔇"
                    binding.btnMicMute.setBackgroundColor(Color.parseColor("#E11D48"))
                } else {
                    binding.btnMicMute.text = "میوت من 🎙️"
                    binding.btnMicMute.setBackgroundColor(Color.parseColor("#161F33"))
                }

                if (st.isRoomDeafened) {
                    binding.btnRoomDeafen.text = "سکوت اتاق: فعال 🔇"
                    binding.btnRoomDeafen.setBackgroundColor(Color.parseColor("#D97706"))
                } else {
                    binding.btnRoomDeafen.text = "سکوت اتاق 🔊"
                    binding.btnRoomDeafen.setBackgroundColor(Color.parseColor("#161F33"))
                }

                binding.layoutVoiceMembers.visibility = View.VISIBLE
                binding.layoutVoiceMembers.removeAllViews()
                st.members.forEach { member ->
                    val tv = TextView(this).apply {
                        val icon = when {
                            member.isMuted -> "🔇"
                            member.isSpeaking -> "🟢"
                            else -> "⚪"
                        }
                        val speakingTag = if (member.isSpeaking && !member.isMuted) "  (در حال صحبت)" else ""
                        text = "$icon  ${member.displayName}$speakingTag"
                        textSize = 13f
                        setPadding(8, 8, 8, 8)
                        setTextColor(
                            Color.parseColor(
                                when {
                                    member.isSpeaking && !member.isMuted -> "#10B981"
                                    member.isMuted -> "#94A3B8"
                                    else -> "#F8FAFC"
                                }
                            )
                        )
                    }
                    binding.layoutVoiceMembers.addView(tv)
                }
            }
            VoiceConnStatus.ERROR -> {
                binding.tvVoiceStatus.text = "خطا 🔴"
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#FB7185"))
                binding.btnVoiceJoin.isEnabled = true
                binding.btnVoiceJoin.text = "تلاش مجدد برای ورود به ویس"
                binding.btnVoiceJoin.setBackgroundColor(Color.parseColor("#0284C7"))
                binding.layoutVoiceControls.visibility = View.GONE
                binding.layoutVoiceMembers.visibility = View.GONE
                binding.tvVoiceError.visibility = View.VISIBLE
                binding.tvVoiceError.text = st.errorMessage
                binding.etVoiceRoom.isEnabled = true
                binding.etVoiceNickname.isEnabled = true
            }
        }
    }

    private fun registerLiveNetworkMonitor() {
        if (networkCallbackRegistered) return
        try {
            connectivityManager.registerNetworkCallback(
                NetworkRequest.Builder().build(),
                liveNetworkCallback
            )
            networkCallbackRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun unregisterLiveNetworkMonitor() {
        if (!networkCallbackRegistered) return
        try {
            connectivityManager.unregisterNetworkCallback(liveNetworkCallback)
        } catch (_: Exception) {
        } finally {
            networkCallbackRegistered = false
        }
    }

    private fun requestNotifPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupClickListeners() {
        binding.chipModeWarp.setOnClickListener {
            userManuallyPickedMode = true
            updateModePanelsVisibility()
        }
        binding.chipModeDns.setOnClickListener {
            userManuallyPickedMode = true
            updateModePanelsVisibility()
        }

        binding.btnManageConfigs.setOnClickListener {
            showManageConfigsDialog()
        }

        binding.btnRescanConfigs.setOnClickListener {
            runBackgroundConfigScan(autoConnectAfter = false, silent = false)
        }

        binding.btnStartStop.setOnClickListener {
            if (isAuditingDns) return@setOnClickListener
            refreshDeviceProfile()
            if (AlbionDnsVpnService.isRunning || AlbionXrayVpnService.isRunning) {
                stopAllGuards()
            } else if (binding.chipModeWarp.isChecked) {
                val readyGroup = getSelectedGroup5()
                if (readyGroup != null && readyGroup.nodes.isNotEmpty()) {
                    // ZERO-WAIT INSTANT CONNECTION from cached 5-config pack!
                    connectSelectedGroupInstantly(readyGroup)
                } else {
                    runBackgroundConfigScan(autoConnectAfter = true, silent = false)
                }
            } else {
                startSmartAuditAndConnect()
            }
        }

        binding.btnCheckUpdate.setOnClickListener {
            checkUpdatesManually()
        }

        binding.btnCopyDns.setOnClickListener {
            val ips = AlbionDnsVpnService.activeDnsPairIps.ifBlank {
                lastReport?.let { r ->
                    val p = r.selectedDns.primary
                    val s = r.backupDns?.primary ?: r.selectedDns.secondary
                    "$p / $s"
                } ?: ""
            }
            if (ips.isBlank()) {
                Toast.makeText(this, "ابتدا یک‌بار Start را بزنید.", Toast.LENGTH_SHORT).show()
            } else {
                val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("AlbionGuard DNS", ips))
                Toast.makeText(this, "آی‌پی‌های DNS کپی شد: $ips", Toast.LENGTH_LONG).show()
            }
        }

        binding.btnVoiceJoin.setOnClickListener {
            val currentStatus = LiveKitVoiceService.state.value.status
            if (currentStatus == VoiceConnStatus.CONNECTED || currentStatus == VoiceConnStatus.CONNECTING) {
                val intent = Intent(this, LiveKitVoiceService::class.java).apply {
                    action = LiveKitVoiceService.ACTION_LEAVE
                }
                startService(intent)
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startInlineVoiceRoom()
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }

        binding.btnMicMute.setOnClickListener {
            startService(Intent(this, LiveKitVoiceService::class.java).apply {
                action = LiveKitVoiceService.ACTION_TOGGLE_MUTE
            })
        }

        binding.btnRoomDeafen.setOnClickListener {
            startService(Intent(this, LiveKitVoiceService::class.java).apply {
                action = LiveKitVoiceService.ACTION_TOGGLE_DEAFEN
            })
        }

        binding.btnLaunchAlbion.setOnClickListener {
            val launchIntent = packageManager.getLaunchIntentForPackage(NetworkProfiler.ALBION_PACKAGE)
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this, "بازی Albion Online روی این گوشی نصب نیست.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnFixPrivateDns.setOnClickListener { openNetworkSettings() }
        binding.btnFixPowerSaving.setOnClickListener { openPowerSavingSettings() }
        binding.btnBatteryFix.setOnClickListener { requestBatteryExemption() }
        binding.btnNetworkLock.setOnClickListener { openMobileNetworkSettings() }
    }

    private fun startInlineVoiceRoom() {
        val room = LiveKitVoiceService.sanitizeRoomCode(binding.etVoiceRoom.text.toString())
        val nickname = binding.etVoiceNickname.text.toString().trim().ifBlank { Build.MODEL }
        binding.etVoiceRoom.setText(room)
        getSharedPreferences("albion_guard_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("voice_room", room)
            .putString("voice_nickname", nickname)
            .apply()

        val intent = Intent(this, LiveKitVoiceService::class.java).apply {
            action = LiveKitVoiceService.ACTION_JOIN
            putExtra(LiveKitVoiceService.EXTRA_ROOM_CODE, room)
            putExtra(LiveKitVoiceService.EXTRA_DISPLAY_NAME, nickname)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun refreshDeviceProfile() {
        val profile = NetworkProfiler.inspect(this)
        binding.tvDeviceModel.text = profile.deviceLabel
        binding.tvNetworkInfo.text = "${profile.networkType}  •  ${profile.carrierName}"
        if (!userManuallyPickedMode && !AlbionDnsVpnService.isRunning && !AlbionXrayVpnService.isRunning) {
            if (profile.isWifi) {
                binding.chipModeDns.isChecked = true
            } else {
                binding.chipModeWarp.isChecked = true
            }
            updateModePanelsVisibility()
        }

        if (profile.isPrivateDnsHostnameActive) {
            binding.cardPrivateDnsWarning.visibility = View.VISIBLE
            binding.tvPrivateDnsWarningText.text =
                "Private DNS گوشی (${profile.privateDnsSpecifier}) روشن است و روی همراه اول/ایرانسل باعث قطع اینترنت می‌شود. لطفاً روی Automatic یا Off بگذارید."
        } else {
            binding.cardPrivateDnsWarning.visibility = View.GONE
        }

        binding.cardPowerSavingWarning.visibility =
            if (profile.isPowerSaveMode) View.VISIBLE else View.GONE

        binding.tvBatteryStatus.text = if (profile.isBatteryUnrestricted) {
            "آزادسازی باتری: فعال ✅"
        } else {
            "آزادسازی باتری: نیاز به تأیید ⚠️"
        }
        binding.btnBatteryFix.isEnabled = !profile.isBatteryUnrestricted
        binding.btnBatteryFix.alpha = if (profile.isBatteryUnrestricted) 0.5f else 1.0f

        binding.btnLaunchAlbion.text = if (profile.isAlbionInstalled) {
            "ورود مستقیم به آلبیون آنلاین"
        } else {
            "آلبیون آنلاین یافت نشد"
        }
    }

    private fun syncRunningState() {
        if (isAuditingDns) return
        if (AlbionXrayVpnService.state.value.status == XrayTunnelStatus.RUNNING) {
            binding.btnStartStop.isEnabled = true
            binding.btnStartStop.text = "توقف"
            binding.btnStartStop.setBackgroundColor(Color.parseColor("#E11D48"))
            binding.tvActiveDnsValue.text = AlbionXrayVpnService.activeLabel
        } else if (AlbionDnsVpnService.isRunning) {
            binding.btnStartStop.isEnabled = true
            binding.btnStartStop.text = "توقف"
            binding.btnStartStop.setBackgroundColor(Color.parseColor("#E11D48"))
            binding.tvActiveDnsValue.text = AlbionDnsVpnService.activeDnsName
        } else {
            resetIdleUi()
        }
    }

    private fun startSmartAuditAndConnect() {
        isAuditingDns = true
        binding.btnStartStop.isEnabled = false
        binding.btnStartStop.text = "در حال تست..."
        binding.progressAudit.visibility = View.VISIBLE
        binding.progressAudit.progress = 5
        binding.cardVerdict.visibility = View.GONE
        binding.btnLaunchAlbion.visibility = View.GONE
        binding.cardQuickSwitch.visibility = View.GONE
        binding.tvStatusHeadline.text = "در حال بررسی بهترین ترکیب DNS برای سرور اروپا..."

        lifecycleScope.launch {
            val report = AlbionAuditEngine.runFullAudit { stepText, percent ->
                runOnUiThread {
                    binding.tvStatusHeadline.text = stepText
                    binding.progressAudit.progress = percent
                }
            }

            isAuditingDns = false
            lastReport = report
            binding.btnStartStop.isEnabled = true
            binding.progressAudit.visibility = View.GONE
            refreshDeviceProfile()
            applyAuditReportToUi(report)

            if (report.readiness != ReadinessLevel.NEEDS_TUNNEL) {
                val pool = report.topWorkingDns.map { it.preset }.ifEmpty { listOf(report.selectedDns) }
                requestVpnAndStart(pool)
            } else {
                resetIdleUi()
            }
        }
    }

    private fun applyAuditReportToUi(report: AuditReport) {
        binding.tvPingValue.text = if (report.avgPingMs < 999) "${report.avgPingMs} ms" else "—"
        binding.tvJitterValue.text = "${report.jitterMs} ms"
        binding.tvLossValue.text = "${report.packetLossPct}%"
        binding.tvActiveDnsValue.text = report.selectedDns.name

        populateQuickSwitchChips(report)

        binding.cardVerdict.visibility = View.VISIBLE
        binding.tvVerdictTitle.text = report.summaryTitle
        binding.tvVerdictDetail.text = report.summaryDetail

        when (report.readiness) {
            ReadinessLevel.READY -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#06281E"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#10B981"))
                binding.tvStatusHeadline.text = "تأیید شد — مسیر ترکیبی پایدار است 🟢"
                binding.btnLaunchAlbion.visibility = View.VISIBLE
            }
            ReadinessLevel.CAUTION -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2A1F0D"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#F59E0B"))
                binding.tvStatusHeadline.text = "متصل با هشدار نوسان خط 🟡"
                binding.btnLaunchAlbion.visibility = View.VISIBLE
            }
            ReadinessLevel.NEEDS_TUNNEL -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2A111A"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#FB7185"))
                binding.tvStatusHeadline.text = "مسیر مستقیم روی این نت بسته است 🔴"
                binding.btnLaunchAlbion.visibility = View.GONE
            }
        }
    }

    private fun populateQuickSwitchChips(report: AuditReport) {
        binding.chipGroupTopDns.removeAllViews()
        if (report.topWorkingDns.size <= 1) {
            binding.cardQuickSwitch.visibility = View.GONE
            return
        }
        binding.cardQuickSwitch.visibility = View.VISIBLE
        report.topWorkingDns.forEach { probe ->
            val chip = Chip(this).apply {
                text = "${probe.preset.name.substringBefore(" (")} • ${probe.dnsLatencyMs}ms"
                isCheckable = true
                isChecked = probe.preset.id == report.selectedDns.id
                setTextColor(Color.parseColor("#F8FAFC"))
                setChipBackgroundColorResource(android.R.color.transparent)
                setOnClickListener {
                    val reordered = listOf(probe.preset) +
                        report.topWorkingDns.map { it.preset }.filter { it.id != probe.preset.id }
                    binding.tvActiveDnsValue.text = probe.preset.name
                    requestVpnAndStart(reordered)
                    Toast.makeText(
                        this@MainActivity,
                        "تغییر سریع به ${probe.preset.name} فعال شد",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            binding.chipGroupTopDns.addView(chip)
        }
    }

    private fun requestVpnAndStart(pool: List<DnsPreset>) {
        pendingPool = pool
        val prepIntent = VpnService.prepare(this)
        if (prepIntent != null) {
            vpnPermissionLauncher.launch(prepIntent)
        } else {
            startVpnWithPool(pool)
        }
    }

    private fun startVpnWithPool(pool: List<DnsPreset>) {
        val primaryPreset = pool.first()
        val ips = arrayListOf(primaryPreset.primary, primaryPreset.secondary)
        val names = arrayListOf(primaryPreset.name)

        val intent = Intent(this, AlbionDnsVpnService::class.java).apply {
            action = AlbionDnsVpnService.ACTION_START
            putStringArrayListExtra(AlbionDnsVpnService.EXTRA_DNS_IPS, ips)
            putStringArrayListExtra(AlbionDnsVpnService.EXTRA_DNS_NAMES, names)
        }
        ContextCompat.startForegroundService(this, intent)
        binding.btnStartStop.text = "توقف"
        binding.btnStartStop.setBackgroundColor(Color.parseColor("#E11D48"))
    }

    private fun stopGuardService() {
        val intent = Intent(this, AlbionDnsVpnService::class.java).apply {
            action = AlbionDnsVpnService.ACTION_STOP
        }
        startService(intent)
        resetIdleUi()
        binding.tvStatusHeadline.text = "متوقف شد • برای اتصال مجدد Start را بزنید"
    }

    private fun resetIdleUi() {
        binding.btnStartStop.isEnabled = true
        binding.btnStartStop.text = "شروع (START)"
        binding.btnStartStop.setBackgroundColor(Color.parseColor("#10B981"))
    }

    private fun checkUpdatesSilently() {
        lifecycleScope.launch {
            val release = UpdateChecker.checkForUpdate(BuildConfig.VERSION_NAME)
            if (release != null) showUpdateDialog(release)
        }
    }

    private fun checkUpdatesManually() {
        binding.btnCheckUpdate.isEnabled = false
        binding.btnCheckUpdate.text = "..."
        lifecycleScope.launch {
            val release = UpdateChecker.checkForUpdate(BuildConfig.VERSION_NAME)
            binding.btnCheckUpdate.isEnabled = true
            binding.btnCheckUpdate.text = "Update"
            if (release != null) {
                showUpdateDialog(release)
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "شما آخرین نسخه (v${BuildConfig.VERSION_NAME}) را دارید ✅",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showUpdateDialog(release: ReleaseInfo) {
        AlertDialog.Builder(this)
            .setTitle("نسخه جدید آماده است (v${release.versionName})")
            .setMessage(release.releaseNotes)
            .setPositiveButton("دانلود و نصب") { _, _ -> downloadAndInstallUpdate(release) }
            .setNegativeButton("بعداً", null)
            .show()
    }

    private fun downloadAndInstallUpdate(release: ReleaseInfo) {
        val progressDialog = AlertDialog.Builder(this)
            .setTitle("در حال دانلود نسخه v${release.versionName}")
            .setMessage("لطفاً صبر کنید... 0%")
            .setCancelable(false)
            .create()
        progressDialog.show()

        lifecycleScope.launch {
            val apkFile = UpdateChecker.downloadApk(this@MainActivity, release.apkDownloadUrl) { pct ->
                runOnUiThread { progressDialog.setMessage("در حال دانلود... $pct%") }
            }
            progressDialog.dismiss()
            if (apkFile != null) {
                UpdateChecker.installApk(this@MainActivity, apkFile)
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "دانلود ناموفق بود؛ از اتصال اینترنت مطمئن شوید.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun openNetworkSettings() {
        try {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openPowerSavingSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openMobileNetworkSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS))
        } catch (_: Exception) {
            openNetworkSettings()
        }
    }

    private fun showManageConfigsDialog() {
        val input = EditText(this).apply {
            hint = "کانفیگ‌های vless:// یا ss:// یا trojan:// را اینجا پیست کنید..."
            minLines = 6
            maxLines = 12
            textSize = 12f
            setText(GuildConfigStore.getManualConfigs(this@MainActivity))
            setPadding(24, 20, 24, 20)
        }

        AlertDialog.Builder(this)
            .setTitle("مدیریت کانفیگ‌ها (VLESS / SS / Trojan)")
            .setMessage("کانفیگ‌ها را پیست کنید تا همان لحظه بر اساس کشور جدا شوند، تست شوند و در گروه‌های ۵تایی آماده اتصال فوری قرار بگیرند.")
            .setView(input)
            .setPositiveButton("ذخیره و جداسازی کشوری") { _, _ ->
                val raw = input.text.toString()
                GuildConfigStore.saveManualConfigs(this, raw)
                Toast.makeText(this, "در حال جداسازی کشوری و ساخت گروه‌های ۵تایی...", Toast.LENGTH_SHORT).show()
                runBackgroundConfigScan(autoConnectAfter = false, silent = false)
            }
            .setNeutralButton("فقط آلمان 🇩🇪") { _, _ ->
                val raw = input.text.toString()
                Toast.makeText(this, "در حال جداسازی و تست کانفیگ‌های آلمان...", Toast.LENGTH_SHORT).show()
                lifecycleScope.launch {
                    val (deNodes, total) = GuildConfigStore.filterGermanyOnly(raw)
                    val filteredText = deNodes.joinToString("\n") { it.rawUri }
                    GuildConfigStore.saveManualConfigs(this@MainActivity, filteredText)
                    Toast.makeText(
                        this@MainActivity,
                        "از $total کانفیگ، ${deNodes.size} کانفیگ آلمان 🇩🇪 نگه داشته شد",
                        Toast.LENGTH_SHORT
                    ).show()
                    runBackgroundConfigScan(autoConnectAfter = false, silent = false, onlyCountryCode = "DE")
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun startXrayServiceNow(
        configJson: String,
        fallbackJson: String,
        label: String,
        pingMs: Int,
        poolCount: Int
    ) {
        val intent = Intent(this, AlbionXrayVpnService::class.java).apply {
            action = AlbionXrayVpnService.ACTION_START
            putExtra(AlbionXrayVpnService.EXTRA_CONFIG_JSON, configJson)
            putExtra(AlbionXrayVpnService.EXTRA_FALLBACK_CONFIG_JSON, fallbackJson)
            putExtra(AlbionXrayVpnService.EXTRA_ACTIVE_LABEL, label)
            putExtra(AlbionXrayVpnService.EXTRA_ACTIVE_PING_MS, pingMs)
            putExtra(AlbionXrayVpnService.EXTRA_POOL_COUNT, poolCount)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopAllGuards() {
        if (AlbionXrayVpnService.isRunning) {
            startService(Intent(this, AlbionXrayVpnService::class.java).apply {
                action = AlbionXrayVpnService.ACTION_STOP
            })
        }
        if (AlbionDnsVpnService.isRunning) {
            stopGuardService()
        } else {
            resetIdleUi()
            binding.cardVerdict.visibility = View.GONE
            binding.btnLaunchAlbion.visibility = View.GONE
            binding.tvStatusHeadline.text = "متوقف شد • برای اتصال مجدد Start را بزنید"
        }
    }

    private fun observeXrayState() {
        lifecycleScope.launch {
            AlbionXrayVpnService.state.collect { st ->
                when (st.status) {
                    XrayTunnelStatus.CONNECTING -> {
                        binding.btnStartStop.isEnabled = false
                        binding.btnStartStop.text = "در حال اتصال..."
                        binding.tvStatusHeadline.text = "در حال برقراری تونل واقعی Xray (${st.activeLabel})..."
                    }
                    XrayTunnelStatus.RUNNING -> {
                        binding.btnStartStop.isEnabled = true
                        binding.btnStartStop.text = "توقف"
                        binding.btnStartStop.setBackgroundColor(Color.parseColor("#E11D48"))

                        binding.cardVerdict.visibility = View.VISIBLE
                        binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#06281E"))
                        binding.tvVerdictTitle.setTextColor(Color.parseColor("#10B981"))
                        binding.tvVerdictTitle.text = "تونل گیمینگ متصل شد 🟢"
                        binding.tvVerdictDetail.text =
                            "اتصال واقعی برقرار است (${st.activeLabel} • ${st.poolCount} سرور با سوئیچ خودکار). علامت کلید VPN بالای صفحه فعال شده و فقط آلبیون داخل تونل است."
                        binding.tvStatusHeadline.text =
                            "متصل • فقط آلبیون داخل تونل (${st.activeLabel})"
                        binding.btnLaunchAlbion.visibility = View.VISIBLE
                    }
                    XrayTunnelStatus.ERROR -> {
                        resetIdleUi()
                        binding.cardVerdict.visibility = View.VISIBLE
                        binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2A111A"))
                        binding.tvVerdictTitle.setTextColor(Color.parseColor("#FB7185"))
                        binding.tvVerdictTitle.text = "خطا در اتصال تونل 🔴"
                        binding.tvVerdictDetail.text = st.errorMessage
                        binding.tvStatusHeadline.text = "اتصال برقرار نشد — گروه یا کشور دیگری انتخاب کنید"
                        binding.btnLaunchAlbion.visibility = View.GONE
                    }
                    XrayTunnelStatus.IDLE -> {
                        if (!isAuditingDns && !AlbionDnsVpnService.isRunning) {
                            resetIdleUi()
                        }
                    }
                }
            }
        }
    }
}
