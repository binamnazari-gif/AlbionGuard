package com.albionguard.eu

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.albionguard.eu.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingReport: AuditReport? = null
    private var isAuditing = false

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingReport?.let { startVpnWithReport(it) }
        } else {
            Toast.makeText(this, "برای ست کردن خودکار DNS، اجازه VPN لازم است.", Toast.LENGTH_LONG).show()
            resetIdleUi()
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* optional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestNotifPermissionIfNeeded()
        setupClickListeners()
        refreshDeviceProfile()
        syncRunningState()
    }

    override fun onResume() {
        super.onResume()
        refreshDeviceProfile()
        syncRunningState()
    }

    private fun requestNotifPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnStartStop.setOnClickListener {
            if (isAuditing) return@setOnClickListener
            if (AlbionDnsVpnService.isRunning) {
                stopGuardService()
            } else {
                startSmartAuditAndConnect()
            }
        }

        binding.btnLaunchAlbion.setOnClickListener {
            val launchIntent = packageManager.getLaunchIntentForPackage(NetworkProfiler.ALBION_PACKAGE)
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this, "بازی Albion Online روی این گوشی نصب نیست.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnFixPrivateDns.setOnClickListener {
            openNetworkSettings()
        }

        binding.btnBatteryFix.setOnClickListener {
            requestBatteryExemption()
        }

        binding.btnNetworkLock.setOnClickListener {
            openMobileNetworkSettings()
        }
    }

    private fun refreshDeviceProfile() {
        val profile = NetworkProfiler.inspect(this)
        binding.tvDeviceModel.text = profile.deviceLabel
        binding.tvNetworkInfo.text = "${profile.networkType} • ${profile.carrierName}"

        // Critical warning if Android Private DNS (Port 853) is manually set
        if (profile.isPrivateDnsHostnameActive) {
            binding.cardPrivateDnsWarning.visibility = View.VISIBLE
            binding.tvPrivateDnsWarningText.text =
                "Private DNS گوشی (${profile.privateDnsSpecifier}) روشن است و روی همراه اول/ایرانسل باعث قطع اینترنت می‌شود. لطفاً روی Automatic یا Off بگذارید."
        } else {
            binding.cardPrivateDnsWarning.visibility = View.GONE
        }

        binding.tvBatteryStatus.text = if (profile.isBatteryUnrestricted) {
            "آزادسازی باتری: فعال ✅"
        } else {
            "آزادسازی باتری: نیاز به تأیید ⚠️"
        }
        binding.btnBatteryFix.isEnabled = !profile.isBatteryUnrestricted
        binding.btnBatteryFix.alpha = if (profile.isBatteryUnrestricted) 0.5f else 1.0f

        binding.btnLaunchAlbion.text = if (profile.isAlbionInstalled) {
            "ورود مستقیم به آلبیون آنلاین"
        } else {
            "آلبیون آنلاین یافت نشد"
        }
    }

    private fun syncRunningState() {
        if (AlbionDnsVpnService.isRunning && !isAuditing) {
            binding.btnStartStop.text = "توقف"
            binding.btnStartStop.setBackgroundColor(Color.parseColor("#DA3633"))
            binding.tvActiveDnsValue.text = AlbionDnsVpnService.activeDnsName
            AlbionDnsVpnService.lastLivePingMs?.let {
                binding.tvPingValue.text = "${it} ms"
            }
        }
    }

    private fun startSmartAuditAndConnect() {
        isAuditing = true
        binding.btnStartStop.isEnabled = false
        binding.btnStartStop.text = "در حال تست..."
        binding.progressAudit.visibility = View.VISIBLE
        binding.progressAudit.progress = 5
        binding.cardVerdict.visibility = View.GONE
        binding.btnLaunchAlbion.visibility = View.GONE
        binding.tvStatusHeadline.text = "در حال بررسی بهترین مسیر به سرور اروپا..."

        lifecycleScope.launch {
            val report = AlbionAuditEngine.runFullAudit { stepText, percent ->
                runOnUiThread {
                    binding.tvStatusHeadline.text = stepText
                    binding.progressAudit.progress = percent
                }
            }

            isAuditing = false
            binding.btnStartStop.isEnabled = true
            binding.progressAudit.visibility = View.GONE
            applyAuditReportToUi(report)

            if (report.readiness != ReadinessLevel.NEEDS_TUNNEL) {
                pendingReport = report
                val prepIntent = VpnService.prepare(this@MainActivity)
                if (prepIntent != null) {
                    vpnPermissionLauncher.launch(prepIntent)
                } else {
                    startVpnWithReport(report)
                }
            } else {
                resetIdleUi()
            }
        }
    }

    private fun applyAuditReportToUi(report: AuditReport) {
        binding.tvPingValue.text = if (report.avgPingMs < 999) "${report.avgPingMs} ms" else "—"
        binding.tvJitterValue.text = "${report.jitterMs} ms"
        binding.tvLossValue.text = "${report.packetLossPct}%"
        binding.tvActiveDnsValue.text = report.selectedDns.name

        binding.cardVerdict.visibility = View.VISIBLE
        binding.tvVerdictTitle.text = report.summaryTitle
        binding.tvVerdictDetail.text = report.summaryDetail

        when (report.readiness) {
            ReadinessLevel.READY -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#132A1C"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#3FB950"))
                binding.tvStatusHeadline.text = "تأیید شد — مسیر پایدار است 🟢"
                binding.btnLaunchAlbion.visibility = View.VISIBLE
            }
            ReadinessLevel.CAUTION -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2E2312"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#D29922"))
                binding.tvStatusHeadline.text = "متصل با هشدار نوسان خط 🟡"
                binding.btnLaunchAlbion.visibility = View.VISIBLE
            }
            ReadinessLevel.NEEDS_TUNNEL -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#311517"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#F85149"))
                binding.tvStatusHeadline.text = "مسیر مستقیم روی این نت بسته است 🔴"
                binding.btnLaunchAlbion.visibility = View.GONE
            }
        }
    }

    private fun startVpnWithReport(report: AuditReport) {
        val intent = Intent(this, AlbionDnsVpnService::class.java).apply {
            action = AlbionDnsVpnService.ACTION_START
            putExtra(AlbionDnsVpnService.EXTRA_PRIMARY_DNS, report.selectedDns.primary)
            putExtra(AlbionDnsVpnService.EXTRA_SECONDARY_DNS, report.selectedDns.secondary)
            putExtra(AlbionDnsVpnService.EXTRA_DNS_NAME, report.selectedDns.name)
        }
        ContextCompat.startForegroundService(this, intent)
        binding.btnStartStop.text = "توقف"
        binding.btnStartStop.setBackgroundColor(Color.parseColor("#DA3633"))
    }

    private fun stopGuardService() {
        val intent = Intent(this, AlbionDnsVpnService::class.java).apply {
            action = AlbionDnsVpnService.ACTION_STOP
        }
        startService(intent)
        resetIdleUi()
        binding.tvStatusHeadline.text = "متوقف شد • برای تست مجدد Start را بزنید"
    }

    private fun resetIdleUi() {
        binding.btnStartStop.text = "شروع (START)"
        binding.btnStartStop.setBackgroundColor(Color.parseColor("#238636"))
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun openNetworkSettings() {
        try {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openMobileNetworkSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS))
        } catch (_: Exception) {
            openNetworkSettings()
        }
    }
}
