package com.albionguard.eu

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.albionguard.eu.databinding.ActivityMainBinding
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingPool: List<DnsPreset> = emptyList()
    private var lastReport: AuditReport? = null
    private var isAuditing = false
    private var networkCallbackRegistered = false

    private val connectivityManager by lazy {
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    private val liveNetworkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { refreshDeviceProfile() }
        }

        override fun onLost(network: Network) {
            runOnUiThread { refreshDeviceProfile() }
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            if (pendingPool.isNotEmpty()) startVpnWithPool(pendingPool)
        } else {
            Toast.makeText(this, "برای ست کردن خودکار DNS، اجازه VPN لازم است.", Toast.LENGTH_LONG).show()
            resetIdleUi()
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* optional */ }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startInlineVoiceRoom()
        } else {
            Toast.makeText(this, "برای ورود به ویس گیلد، اجازه میکروفون لازم است.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvVersionBadge.text = "v${BuildConfig.VERSION_NAME}"
        val prefs = getSharedPreferences("albion_guard_prefs", Context.MODE_PRIVATE)
        binding.etVoiceRoom.setText(prefs.getString("voice_room", "albion-iran") ?: "albion-iran")
        binding.etVoiceNickname.setText(prefs.getString("voice_nickname", "") ?: "")

        requestNotifPermissionIfNeeded()
        setupClickListeners()
        observeVoiceState()
        refreshDeviceProfile()
        syncRunningState()
        checkUpdatesSilently()
    }

    override fun onStart() {
        super.onStart()
        registerLiveNetworkMonitor()
    }

    override fun onStop() {
        super.onStop()
        unregisterLiveNetworkMonitor()
    }

    override fun onResume() {
        super.onResume()
        refreshDeviceProfile()
        syncRunningState()
    }

    private fun observeVoiceState() {
        lifecycleScope.launch {
            LiveKitVoiceService.state.collect { st ->
                renderVoiceState(st)
            }
        }
    }

    private fun renderVoiceState(st: VoiceUiState) {
        when (st.status) {
            VoiceConnStatus.IDLE -> {
                binding.tvVoiceStatus.text = "خاموش"
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#64748B"))
                binding.btnVoiceJoin.isEnabled = true
                binding.btnVoiceJoin.text = "ورود به ویس"
                binding.btnVoiceJoin.setBackgroundColor(Color.parseColor("#0284C7"))
                binding.layoutVoiceControls.visibility = View.GONE
                binding.layoutVoiceMembers.visibility = View.GONE
                binding.tvVoiceError.visibility = View.GONE
                binding.etVoiceRoom.isEnabled = true
                binding.etVoiceNickname.isEnabled = true
            }
            VoiceConnStatus.CONNECTING -> {
                binding.tvVoiceStatus.text = "در حال اتصال..."
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#F59E0B"))
                binding.btnVoiceJoin.isEnabled = false
                binding.btnVoiceJoin.text = "در حال اتصال به اتاق..."
                binding.layoutVoiceControls.visibility = View.GONE
                binding.layoutVoiceMembers.visibility = View.GONE
                binding.tvVoiceError.visibility = View.GONE
                binding.etVoiceRoom.isEnabled = false
                binding.etVoiceNickname.isEnabled = false
            }
            VoiceConnStatus.CONNECTED -> {
                val count = st.members.size.coerceAtLeast(1)
                binding.tvVoiceStatus.text = "متصل ($count نفر) 🟢"
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#10B981"))
                binding.btnVoiceJoin.isEnabled = true
                binding.btnVoiceJoin.text = "خروج از ویس"
                binding.btnVoiceJoin.setBackgroundColor(Color.parseColor("#E11D48"))
                binding.layoutVoiceControls.visibility = View.VISIBLE
                binding.tvVoiceError.visibility = View.GONE
                binding.etVoiceRoom.isEnabled = false
                binding.etVoiceNickname.isEnabled = false

                // Sync Mute & Deafen buttons
                if (st.isMicMuted) {
                    binding.btnMicMute.text = "میوت من: فعال 🔇"
                    binding.btnMicMute.setBackgroundColor(Color.parseColor("#E11D48"))
                } else {
                    binding.btnMicMute.text = "میوت من 🎙️"
                    binding.btnMicMute.setBackgroundColor(Color.parseColor("#161F33"))
                }

                if (st.isRoomDeafened) {
                    binding.btnRoomDeafen.text = "سکوت اتاق: فعال 🔇"
                    binding.btnRoomDeafen.setBackgroundColor(Color.parseColor("#D97706"))
                } else {
                    binding.btnRoomDeafen.text = "سکوت اتاق 🔊"
                    binding.btnRoomDeafen.setBackgroundColor(Color.parseColor("#161F33"))
                }

                // Render live Persian participant list right inside the card!
                binding.layoutVoiceMembers.visibility = View.VISIBLE
                binding.layoutVoiceMembers.removeAllViews()
                st.members.forEach { member ->
                    val tv = TextView(this).apply {
                        val icon = when {
                            member.isMuted -> "🔇"
                            member.isSpeaking -> "🟢"
                            else -> "⚪"
                        }
                        val speakingTag = if (member.isSpeaking && !member.isMuted) "  (در حال صحبت)" else ""
                        text = "$icon  ${member.displayName}$speakingTag"
                        textSize = 13f
                        setPadding(8, 8, 8, 8)
                        setTextColor(
                            Color.parseColor(
                                when {
                                    member.isSpeaking && !member.isMuted -> "#10B981"
                                    member.isMuted -> "#94A3B8"
                                    else -> "#F8FAFC"
                                }
                            )
                        )
                    }
                    binding.layoutVoiceMembers.addView(tv)
                }
            }
            VoiceConnStatus.ERROR -> {
                binding.tvVoiceStatus.text = "خطا 🔴"
                binding.tvVoiceStatus.setTextColor(Color.parseColor("#FB7185"))
                binding.btnVoiceJoin.isEnabled = true
                binding.btnVoiceJoin.text = "تلاش مجدد برای ورود به ویس"
                binding.btnVoiceJoin.setBackgroundColor(Color.parseColor("#0284C7"))
                binding.layoutVoiceControls.visibility = View.GONE
                binding.layoutVoiceMembers.visibility = View.GONE
                binding.tvVoiceError.visibility = View.VISIBLE
                binding.tvVoiceError.text = st.errorMessage
                binding.etVoiceRoom.isEnabled = true
                binding.etVoiceNickname.isEnabled = true
            }
        }
    }

    private fun registerLiveNetworkMonitor() {
        if (networkCallbackRegistered) return
        try {
            connectivityManager.registerNetworkCallback(
                NetworkRequest.Builder().build(),
                liveNetworkCallback
            )
            networkCallbackRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun unregisterLiveNetworkMonitor() {
        if (!networkCallbackRegistered) return
        try {
            connectivityManager.unregisterNetworkCallback(liveNetworkCallback)
        } catch (_: Exception) {
        } finally {
            networkCallbackRegistered = false
        }
    }

    private fun requestNotifPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnStartStop.setOnClickListener {
            if (isAuditing) return@setOnClickListener
            refreshDeviceProfile()
            if (AlbionDnsVpnService.isRunning) {
                stopGuardService()
            } else {
                startSmartAuditAndConnect()
            }
        }

        binding.btnCheckUpdate.setOnClickListener {
            checkUpdatesManually()
        }

        binding.btnCopyDns.setOnClickListener {
            val ips = AlbionDnsVpnService.activeDnsPairIps.ifBlank {
                lastReport?.let { r ->
                    val p = r.selectedDns.primary
                    val s = r.backupDns?.primary ?: r.selectedDns.secondary
                    "$p / $s"
                } ?: ""
            }
            if (ips.isBlank()) {
                Toast.makeText(this, "ابتدا یک‌بار Start را بزنید.", Toast.LENGTH_SHORT).show()
            } else {
                val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("AlbionGuard DNS", ips))
                Toast.makeText(this, "آی‌پی‌های DNS کپی شد: $ips", Toast.LENGTH_LONG).show()
            }
        }

        binding.btnVoiceJoin.setOnClickListener {
            val currentStatus = LiveKitVoiceService.state.value.status
            if (currentStatus == VoiceConnStatus.CONNECTED || currentStatus == VoiceConnStatus.CONNECTING) {
                val intent = Intent(this, LiveKitVoiceService::class.java).apply {
                    action = LiveKitVoiceService.ACTION_LEAVE
                }
                startService(intent)
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    startInlineVoiceRoom()
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }

        binding.btnMicMute.setOnClickListener {
            startService(Intent(this, LiveKitVoiceService::class.java).apply {
                action = LiveKitVoiceService.ACTION_TOGGLE_MUTE
            })
        }

        binding.btnRoomDeafen.setOnClickListener {
            startService(Intent(this, LiveKitVoiceService::class.java).apply {
                action = LiveKitVoiceService.ACTION_TOGGLE_DEAFEN
            })
        }

        binding.btnLaunchAlbion.setOnClickListener {
            val launchIntent = packageManager.getLaunchIntentForPackage(NetworkProfiler.ALBION_PACKAGE)
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this, "بازی Albion Online روی این گوشی نصب نیست.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnFixPrivateDns.setOnClickListener {
            openNetworkSettings()
        }

        binding.btnFixPowerSaving.setOnClickListener {
            openPowerSavingSettings()
        }

        binding.btnBatteryFix.setOnClickListener {
            requestBatteryExemption()
        }

        binding.btnNetworkLock.setOnClickListener {
            openMobileNetworkSettings()
        }
    }

    private fun startInlineVoiceRoom() {
        val room = LiveKitVoiceService.sanitizeRoomCode(binding.etVoiceRoom.text.toString())
        val nickname = binding.etVoiceNickname.text.toString().trim().ifBlank { Build.MODEL }
        binding.etVoiceRoom.setText(room)
        getSharedPreferences("albion_guard_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("voice_room", room)
            .putString("voice_nickname", nickname)
            .apply()

        val intent = Intent(this, LiveKitVoiceService::class.java).apply {
            action = LiveKitVoiceService.ACTION_JOIN
            putExtra(LiveKitVoiceService.EXTRA_ROOM_CODE, room)
            putExtra(LiveKitVoiceService.EXTRA_DISPLAY_NAME, nickname)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun refreshDeviceProfile() {
        val profile = NetworkProfiler.inspect(this)
        binding.tvDeviceModel.text = profile.deviceLabel
        binding.tvNetworkInfo.text = "${profile.networkType}  •  ${profile.carrierName}"

        if (profile.isPrivateDnsHostnameActive) {
            binding.cardPrivateDnsWarning.visibility = View.VISIBLE
            binding.tvPrivateDnsWarningText.text =
                "Private DNS گوشی (${profile.privateDnsSpecifier}) روشن است و روی همراه اول/ایرانسل باعث قطع اینترنت می‌شود. لطفاً روی Automatic یا Off بگذارید."
        } else {
            binding.cardPrivateDnsWarning.visibility = View.GONE
        }

        binding.cardPowerSavingWarning.visibility =
            if (profile.isPowerSaveMode) View.VISIBLE else View.GONE

        binding.tvBatteryStatus.text = if (profile.isBatteryUnrestricted) {
            "آزادسازی باتری: فعال ✅"
        } else {
            "آزادسازی باتری: نیاز به تأیید ⚠️"
        }
        binding.btnBatteryFix.isEnabled = !profile.isBatteryUnrestricted
        binding.btnBatteryFix.alpha = if (profile.isBatteryUnrestricted) 0.5f else 1.0f

        binding.btnLaunchAlbion.text = if (profile.isAlbionInstalled) {
            "ورود مستقیم به آلبیون آنلاین"
        } else {
            "آلبیون آنلاین یافت نشد"
        }
    }

    private fun syncRunningState() {
        if (AlbionDnsVpnService.isRunning && !isAuditing) {
            binding.btnStartStop.text = "توقف"
            binding.btnStartStop.setBackgroundColor(Color.parseColor("#E11D48"))
            binding.tvActiveDnsValue.text = AlbionDnsVpnService.activeDnsName

        }
    }

    private fun startSmartAuditAndConnect() {
        isAuditing = true
        binding.btnStartStop.isEnabled = false
        binding.btnStartStop.text = "در حال تست..."
        binding.progressAudit.visibility = View.VISIBLE
        binding.progressAudit.progress = 5
        binding.cardVerdict.visibility = View.GONE
        binding.btnLaunchAlbion.visibility = View.GONE
        binding.cardQuickSwitch.visibility = View.GONE
        binding.tvStatusHeadline.text = "در حال بررسی بهترین ترکیب DNS برای سرور اروپا..."

        lifecycleScope.launch {
            val report = AlbionAuditEngine.runFullAudit { stepText, percent ->
                runOnUiThread {
                    binding.tvStatusHeadline.text = stepText
                    binding.progressAudit.progress = percent
                }
            }

            isAuditing = false
            lastReport = report
            binding.btnStartStop.isEnabled = true
            binding.progressAudit.visibility = View.GONE
            refreshDeviceProfile()
            applyAuditReportToUi(report)

            if (report.readiness != ReadinessLevel.NEEDS_TUNNEL) {
                val pool = report.topWorkingDns.map { it.preset }.ifEmpty { listOf(report.selectedDns) }
                requestVpnAndStart(pool)
            } else {
                resetIdleUi()
            }
        }
    }

    private fun applyAuditReportToUi(report: AuditReport) {
        binding.tvPingValue.text = if (report.avgPingMs < 999) "${report.avgPingMs} ms" else "—"
        binding.tvJitterValue.text = "${report.jitterMs} ms"
        binding.tvLossValue.text = "${report.packetLossPct}%"

        val n1 = report.selectedDns.name.substringBefore(" (")
        val n2 = report.backupDns?.name?.substringBefore(" (")
        binding.tvActiveDnsValue.text = if (n2 != null && n2 != n1) "$n1 + $n2 (ترکیبی)" else report.selectedDns.name

        populateQuickSwitchChips(report)

        binding.cardVerdict.visibility = View.VISIBLE
        binding.tvVerdictTitle.text = report.summaryTitle
        binding.tvVerdictDetail.text = report.summaryDetail

        when (report.readiness) {
            ReadinessLevel.READY -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#06281E"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#10B981"))
                binding.tvStatusHeadline.text = "تأیید شد — مسیر ترکیبی پایدار است 🟢"
                binding.btnLaunchAlbion.visibility = View.VISIBLE
            }
            ReadinessLevel.CAUTION -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2A1F0D"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#F59E0B"))
                binding.tvStatusHeadline.text = "متصل با هشدار نوسان خط 🟡"
                binding.btnLaunchAlbion.visibility = View.VISIBLE
            }
            ReadinessLevel.NEEDS_TUNNEL -> {
                binding.cardVerdict.setCardBackgroundColor(Color.parseColor("#2A111A"))
                binding.tvVerdictTitle.setTextColor(Color.parseColor("#FB7185"))
                binding.tvStatusHeadline.text = "مسیر مستقیم روی این نت بسته است 🔴"
                binding.btnLaunchAlbion.visibility = View.GONE
            }
        }
    }

    private fun populateQuickSwitchChips(report: AuditReport) {
        binding.chipGroupTopDns.removeAllViews()
        if (report.topWorkingDns.size <= 1) {
            binding.cardQuickSwitch.visibility = View.GONE
            return
        }
        binding.cardQuickSwitch.visibility = View.VISIBLE
        report.topWorkingDns.forEach { probe ->
            val chip = Chip(this).apply {
                text = "${probe.preset.name.substringBefore(" (")} • ${probe.dnsLatencyMs}ms"
                isCheckable = true
                isChecked = probe.preset.id == report.selectedDns.id
                setTextColor(Color.parseColor("#F8FAFC"))
                setChipBackgroundColorResource(android.R.color.transparent)
                setOnClickListener {
                    val reordered = listOf(probe.preset) +
                        report.topWorkingDns.map { it.preset }.filter { it.id != probe.preset.id }
                    val n1 = reordered[0].name.substringBefore(" (")
                    val n2 = reordered.getOrNull(1)?.name?.substringBefore(" (")
                    binding.tvActiveDnsValue.text = if (n2 != null) "$n1 + $n2 (ترکیبی)" else n1
                    requestVpnAndStart(reordered)
                    Toast.makeText(
                        this@MainActivity,
                        "تغییر سریع به ترکیب $n1 فعال شد",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            binding.chipGroupTopDns.addView(chip)
        }
    }

    private fun requestVpnAndStart(pool: List<DnsPreset>) {
        pendingPool = pool
        val prepIntent = VpnService.prepare(this)
        if (prepIntent != null) {
            vpnPermissionLauncher.launch(prepIntent)
        } else {
            startVpnWithPool(pool)
        }
    }

    private fun startVpnWithPool(pool: List<DnsPreset>) {
        val ips = ArrayList(pool.map { it.primary })
        val names = ArrayList(pool.map { it.name })
        if (ips.size == 1) {
            ips.add(pool[0].secondary)
            names.add(pool[0].name)
        }

        val intent = Intent(this, AlbionDnsVpnService::class.java).apply {
            action = AlbionDnsVpnService.ACTION_START
            putStringArrayListExtra(AlbionDnsVpnService.EXTRA_DNS_IPS, ips)
            putStringArrayListExtra(AlbionDnsVpnService.EXTRA_DNS_NAMES, names)
        }
        ContextCompat.startForegroundService(this, intent)
        binding.btnStartStop.text = "توقف"
        binding.btnStartStop.setBackgroundColor(Color.parseColor("#E11D48"))
    }

    private fun stopGuardService() {
        val intent = Intent(this, AlbionDnsVpnService::class.java).apply {
            action = AlbionDnsVpnService.ACTION_STOP
        }
        startService(intent)
        resetIdleUi()
        binding.tvStatusHeadline.text = "متوقف شد • برای تست مجدد Start را بزنید"
    }

    private fun resetIdleUi() {
        binding.btnStartStop.text = "شروع (START)"
        binding.btnStartStop.setBackgroundColor(Color.parseColor("#10B981"))
    }

    private fun checkUpdatesSilently() {
        lifecycleScope.launch {
            val release = UpdateChecker.checkForUpdate(BuildConfig.VERSION_NAME)
            if (release != null) {
                showUpdateDialog(release)
            }
        }
    }

    private fun checkUpdatesManually() {
        binding.btnCheckUpdate.isEnabled = false
        binding.btnCheckUpdate.text = "..."
        lifecycleScope.launch {
            val release = UpdateChecker.checkForUpdate(BuildConfig.VERSION_NAME)
            binding.btnCheckUpdate.isEnabled = true
            binding.btnCheckUpdate.text = "Update"
            if (release != null) {
                showUpdateDialog(release)
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "شما آخرین نسخه (v${BuildConfig.VERSION_NAME}) را دارید ✅",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showUpdateDialog(release: ReleaseInfo) {
        AlertDialog.Builder(this)
            .setTitle("نسخه جدید آماده است (v${release.versionName})")
            .setMessage(release.releaseNotes)
            .setPositiveButton("دانلود و نصب") { _, _ ->
                downloadAndInstallUpdate(release)
            }
            .setNegativeButton("بعداً", null)
            .show()
    }

    private fun downloadAndInstallUpdate(release: ReleaseInfo) {
        val progressDialog = AlertDialog.Builder(this)
            .setTitle("در حال دانلود نسخه v${release.versionName}")
            .setMessage("لطفاً صبر کنید... 0%")
            .setCancelable(false)
            .create()
        progressDialog.show()

        lifecycleScope.launch {
            val apkFile = UpdateChecker.downloadApk(this@MainActivity, release.apkDownloadUrl) { pct ->
                runOnUiThread {
                    progressDialog.setMessage("در حال دانلود... $pct%")
                }
            }
            progressDialog.dismiss()
            if (apkFile != null) {
                UpdateChecker.installApk(this@MainActivity, apkFile)
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "دانلود ناموفق بود؛ از اتصال اینترنت مطمئن شوید.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun openNetworkSettings() {
        try {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openPowerSavingSettings() {
        try {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openMobileNetworkSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS))
        } catch (_: Exception) {
            openNetworkSettings()
        }
    }
}
