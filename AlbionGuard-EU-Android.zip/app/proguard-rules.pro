# Keep AlbionGuard classes
-keep class com.albionguard.eu.** { *; }
