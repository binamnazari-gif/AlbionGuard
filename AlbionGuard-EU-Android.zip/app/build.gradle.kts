plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.albionguard.eu"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.albionguard.eu"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "1.4.0"
    }

    signingConfigs {
        create("release") {
            val envPath = System.getenv("KEYSTORE_PATH")
            val bundledKs = rootProject.file("albionguard_release.jks")
            val ksFile = when {
                !envPath.isNullOrBlank() && file(envPath).exists() -> file(envPath)
                bundledKs.exists() -> bundledKs
                else -> null
            }
            if (ksFile != null) {
                storeFile = ksFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "albionguard123"
                keyAlias = System.getenv("KEY_ALIAS") ?: "albionguard"
                keyPassword = System.getenv("KEY_PASSWORD") ?: "albionguard123"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            val relSign = signingConfigs.getByName("release")
            signingConfig = if (relSign.storeFile != null) relSign else signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jitsi.react:jitsi-meet-sdk:10.3.0") {
        isTransitive = true
    }
}
