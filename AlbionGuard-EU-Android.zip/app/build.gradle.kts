plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.albionguard.eu"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.albionguard.eu"
        minSdk = 24
        targetSdk = 34
        versionCode = 19
        versionName = "3.1.1"

        val lkUrl = (System.getenv("LIVEKIT_URL") ?: "").replace("\"", "")
        val lkKey = (System.getenv("LIVEKIT_API_KEY") ?: "").replace("\"", "")
        val lkSecret = (System.getenv("LIVEKIT_API_SECRET") ?: "").replace("\"", "")

        buildConfigField("String", "LIVEKIT_URL", "\"$lkUrl\"")
        buildConfigField("String", "LIVEKIT_API_KEY", "\"$lkKey\"")
        buildConfigField("String", "LIVEKIT_API_SECRET", "\"$lkSecret\"")
    }

    signingConfigs {
        create("release") {
            val envPath = System.getenv("KEYSTORE_PATH")
            val bundledKs = rootProject.file("albionguard_release.jks")
            val ksFile = when {
                !envPath.isNullOrBlank() && file(envPath).exists() -> file(envPath)
                bundledKs.exists() -> bundledKs
                else -> null
            }
            if (ksFile != null) {
                storeFile = ksFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "albionguard123"
                keyAlias = System.getenv("KEY_ALIAS") ?: "albionguard"
                keyPassword = System.getenv("KEY_PASSWORD") ?: "albionguard123"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            val relSign = signingConfigs.getByName("release")
            signingConfig = if (relSign.storeFile != null) relSign else signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("io.livekit:livekit-android:2.14.0")
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar", "*.jar"))))
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.3")
}
